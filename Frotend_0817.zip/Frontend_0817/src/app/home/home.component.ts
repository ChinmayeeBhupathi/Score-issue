import { Component, OnInit, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { finalize } from 'rxjs/operators';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  Validators,
  FormArray
} from '@angular/forms';
import { NgbDateStruct, NgbCalendar, NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { MatRadioChange } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { HomeService } from './home.service';
import { ThemePalette } from '@angular/material/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TooltipPosition } from '@angular/material/tooltip';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  hgt: boolean = true;
  closeResult: string;
  show_loader: boolean = false;
  progressval: any = '30';

  proxyButton: any = false;

  public DirName: any[] = [];

  public tblsrchdata: any = [];
  public ascendsrch: any[] = [];
  public atgsrch: any[] = [];
  public s99_grpsrch: any[] = [];
  dropdownSettingssrch = {};

  scre_tbl: any = [];
  dropdownSettings_scretbl = {};

  tabledata: any = [];

  uniqcol: any = [];

  datecol: any = [];

  custcol: any = [];

  /*ascend score arrays*/
  schema_col: any = [];
  table_col: any = [];
  scre_col: any = [];

  /*ascend score arrays*/

  disable_db: boolean = false;
  disable_cmpny: boolean = true;

  client_company_name: any = '';
  // ascend_company_name: any = '';

  ascend_company_name: any = [];

  trd_col_model: any = [];
  per_col_model: any = 'worst_ever_performance';

  Uniqcustmodel: any = '';
  Hashcustmodel: any = '';
  dec_col_model: any = '';
  appln_date_model: any = '';

  dec_model: any = [];
  good_model: any = [];
  bad_model: any = [];
  loss_model: any = [];
  inter_model: any = [];

  good_model_ascend: any = [];
  inter_model_ascend: any = [];
  bad_model_ascend: any = [];
  loss_model_ascend: any = [];

  book_model: any = [];
  arrpvd_not_model: any = [];

  decline_model: any = [];

  new_ex_model: any = [];
  count: number = 1;

  Trdval: any = [];

  count_sub: number = 1;

  count_scre: number = 1;

  count_scre_asc: number = 1;

  Publicrec: any = 'Y';
  Collectionrec: any = 'Y';
  trades: any = '';
  afterapplndate: any = '';
  tradedata: any = '';
  wrststatmodel: any = '';

  FilteredStartdt: any = '';
  FilteredEnddt: any = '';

  mandatory_req: boolean = false;
  mandatory_req_type2: boolean = true;
  username: any;
  hier_arrayval: any = [];

  /*Scores*/
  Scores: any = [];
  scorecolumn: any = [
    'fast_start_score',
    'fico_v2_score',
    'fico_score_9_score',
    'fico_base_v2_score',
    'fico_risk_v8_score'
  ];
  dropdownList_score: any = [
    {
      item_id_score: 'BK_MDS',
      item_text_score: 'BK_MDS'
    },
    {
      item_id_score: 'BK_PLUS_RESCALED',
      item_text_score: 'BK_PLUS_RESCALED'
    },
    {
      item_id_score: 'FICO_08_AUTO',
      item_text_score: 'FICO_08_AUTO'
    },
    {
      item_id_score: 'FICO_08',
      item_text_score: 'FICO_08'
    },
    {
      item_id_score: 'FICO_09_AUTO',
      item_text_score: 'FICO_09_AUTO'
    },
    {
      item_id_score: 'Credit Cards',
      item_text_score: 'FICO_09'
    },
    {
      item_id_score: 'FICO_V2_AUTO',
      item_text_score: 'FICO_V2_AUTO'
    },
    {
      item_id_score: 'FICO_V2',
      item_text_score: 'FICO_V2'
    },
    {
      item_id_score: 'VANTAGESCORE_3',
      item_text_score: 'VANTAGESCORE_3'
    },
    {
      item_id_score: 'VANTAGESCORE_4',
      item_text_score: 'VANTAGESCORE_4'
    }
  ];
  dropdownSettings_score = {};

  public applnstatus: any[] = [
    'scrambled_app_account_nbr',
    'experian_consumer_key',
    'app_inception_date',
    'decision',
    'seqnum',
    'appdate',
    'gbl009'
  ];
  public dec_type: any[] = [];
  public dec_type_booked: any[] = [];
  public dec_type_approvd: any[] = [];
  public dec_type_decl: any[] = [];

  dec_array: any = [];
  dropdownSettings = {};
  dropdownSettings_bookd = {};

  dropdownSettings_apprvd = {};

  dropdownSettings_declnd = {};

  public good_defn: any[] = [];
  goodSettings = {};

  public bad_defn: any[] = [];
  badSettings = {};

  public inter_defn: any[] = [];
  interSettings = {};

  public loss_defn: any[] = [];
  LossSettings = {};

  /*scres tab*/
  public good_defn_scre: any[] = [];
  goodSettings_scre = {};

  public bad_defn_scre: any[] = [];
  badSettings_scre = {};

  public inter_defn_scre: any[] = [];
  interSettings_scre = {};

  public loss_defn_scre: any[] = [];
  LossSettings_scre = {};

  /*scres tab*/

  public new_ex: any[] = [];
  new_settings = {};

  public dropdownList_trdval: any = [];
  dropdownSettings_trdval = {};

  perfwindmodel: any = '6 months';

  public performancewin: any[] = [
    '6 months',
    '12 months',
    '18 months',
    '24 months',
    '36 months',
    'As of archive date used'
  ];
  public badefinition: any[] = ['0 DPD', '0-30 DPD', '31-60 DPD', '61-90 DPD', '90+ DPD (BK, CO)'];

  public basemonthval: any[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  public baseyearval: any[] = [
    '2010',
    '2011',
    '2012',
    '2013',
    '2014',
    '2015',
    '2016',
    '2017',
    '2018',
    '2019',
    '2020',
    '2021',
    '2022',
    '2023',
    '2024',
    '2025',
    '2026',
    '2027',
    '2028',
    '2029',
    '2030',
    '2031',
    '2032',
    '2033',
    '2034'
  ];

  public proxy: any[] = [
    'Unsecured Loans',
    'Secured Loans',
    'Credit Cards',
    'Auto Loans',
    'Mortages',
    'Home Equity',
    'HELOC',
    'Retail Cards',
    'Student Loans'
  ];

  /*GENERAL*/

  Dirid: any;
  BaseMonth: any = 'Jan';
  BaseYear: any = '2019';
  Tblid: any = [];
  date_format_model: any;
  Dateformat: any = ['mm/dd/yyyy', 'ddMMMyyyy:HH:mm:ss', 'dd-mm-yyyy', 'yyyy-mm-dd'];

  TableName: any = [];
  hiernworex: any = []; //model

  hiernewex: any = ['New', 'Existing']; //
  Wrststatus: any = [
    'Current',
    '30 Days Delinquent',
    '60 Days Delinquent',
    '90 Days Delinquent',
    '120 Days Delinquent',
    '150 Days Delinquent',
    'Derog'
  ];

  ascend_lite_rejecttable_name: any = ['premier_1_2', 'public_record', 'bankruptcy_plus', 'trended_3d'];

  atg_rejecttable_name: any = ['inquiry_company', 'tin_company', 'trade_life_test', 'vantage_3_new'];

  s99_rejecttablename: any = [
    'ca_penfd_bi_c57540a_bicl',
    'ca_penfd_bi_c53012a_bicl',
    'ca_penfd_bi_c62542a_bicl',
    'ca_penfd_bi_c56422a_bicl'
  ];

  ascend_lite_output_name: any = ['premier_1_2', 'public_record', 'bankruptcy_plus', 'trended_3d'];

  atg_outputtable_name: any = ['inquiry_company', 'tin_company', 'trade_life_test', 'vantage_3_new'];

  s99_outputtable_name: any = [
    'ca_penfed_bcus_c57540a_mt',
    'ca_penfed_bcus_c53012a_mt',
    'ca_penfed_bcus_c62542a_mt',
    'ca_penfed_bcus_ c56422a_mt'
  ];

  anArrays: any = [];
  port_arrys: any = [];

  Company: any = [];

  StartDate: NgbDateStruct;
  EndDate: NgbDateStruct;

  Ascend_StartDate: NgbDateStruct;
  Ascend_EndDate: NgbDateStruct;

  prxy1: any = 'Unsecured Loans';

  subarrys: any = [];
  subid: any = [];

  scorearrys: any = [];
  scorenameid: any = [];
  scorecolid: any = [];
  vallow: any = [];
  valhigh: any = [];
  reverse: any = [];

  scorearrys_asc: any = [];
  scoretabnameid: any = [];
  scoreschema_asc: any = [];
  scoretable_asc: any = [];
  scorenameid_asc: any = [];
  scorecolid_asc: any = [];
  vallow_asc: any = [];
  valhigh_asc: any = [];
  reverse_asc: any = [];

  datasrc_check1: boolean = true;
  datasrc_check2: boolean = false;

  /*Mandatory error message*/
  companyname_mand: boolean = true;
  uniqcust_mand: boolean = true;
  hash_mand: boolean = true;
  appldtcol_mand: boolean = true;
  applndtfor_mand: boolean = true;
  applndeccol_mand: boolean = true;
  booked_mand: boolean = true;
  apprvdnt_mand: boolean = true;
  decline_mand: boolean = true;

  asc_cmpnyname_mand: boolean = true;
  subid1_mand: boolean = true;
  trdval_mand: boolean = true;

  good_mand: boolean = true;
  indeter_mand: boolean = true;
  bad_mand: boolean = true;

  tblsrchmand: boolean = true;
  dir_mand: boolean = true;
  validat_model: any = 'portfolio';
  enableportype: boolean = true;

  date_arch_model: any = 'Monthly';
  date_archive: any = ['Monthly', 'Quarterly'];

  /*tab colors*/
  mainstatus: boolean = true;
  clientstatus: boolean = false;
  ascendtatus: boolean = false;
  infstatus: boolean = false;
  screstatus: boolean = false;

  /*tab colors*/
  maincontent: boolean = true;
  clientcontent: boolean = false;
  inferencecontent: boolean = false;
  ascendcontent: boolean = false;
  scorescontent: boolean = false;

  /*performance flag*/

  /*tab disable button*/
  clienttab_disable: boolean = false;
  ascendtab_disable: boolean = true;
  infertab_disable: boolean = true;
  scretab_disable: boolean = false;
  /*tab disable button*/

  show_perflag: boolean = false;

  ascendcmp_valid: boolean = true;
  ascsub_valid: boolean = true;

  asc_good_mand: boolean = true;
  asc_bad_mand: boolean = true;
  scretab_mand: boolean = true;
  SearchfilterUpdate = new Subject<string>();
  ScrefilterUpdate = new Subject<string>();

  env_flag: any;
  usr_id: any;
  passwrd_id: any;

  clientmindt: any;
  ascmindt: any;

  /*Mandatory error message*/

  @ViewChild('div') div: ElementRef;

  constructor(
    private formBuilder: FormBuilder,
    private homeservice: HomeService,
    private renderer: Renderer2,
    private toastr: ToastrService,
    private modalService: NgbModal,
    private router: Router
  ) {
    this.SearchfilterUpdate.pipe(debounceTime(400), distinctUntilChanged()).subscribe(value => {
      this.onFilterChange(value);
    });
  }

  ngOnInit() {
    this.username = localStorage.getItem('name');
    this.usr_id = localStorage.getItem('user_name');
    //this.passwrd_id = localStorage.getItem('password');

    this.Getdir();

    var my_object = JSON.parse(localStorage.getItem('retrivedata'));
    var asc_companyname = JSON.parse(localStorage.getItem('asc_companyname'));
    var subids = JSON.parse(localStorage.getItem('subscriberid'));
    var scorename = JSON.parse(localStorage.getItem('scorename'));
    var scorecolid = JSON.parse(localStorage.getItem('scorecolid'));
    var vallow = JSON.parse(localStorage.getItem('vallow'));
    var valhigh = JSON.parse(localStorage.getItem('valhigh'));
    var reverse = JSON.parse(localStorage.getItem('reverse'));

    var scre_vallow = JSON.parse(localStorage.getItem('scre_vallow'));
    var scre_valhigh = JSON.parse(localStorage.getItem('scre_valhigh'));
    var scre_rev = JSON.parse(localStorage.getItem('scre_rev'));
    var scre_name = JSON.parse(localStorage.getItem('scre_name'));
    var scre_schema = JSON.parse(localStorage.getItem('scre_schema'));
    var scre_table = JSON.parse(localStorage.getItem('scre_table'));

    var scre_tbldata = JSON.parse(localStorage.getItem('scre_tbldata'));

    var scre_columndata = JSON.parse(localStorage.getItem('scre_columndata'));
    var scre_column = JSON.parse(localStorage.getItem('scre_column'));

    var clientgood = JSON.parse(localStorage.getItem('Clientgood'));
    var clientbad = JSON.parse(localStorage.getItem('Clientbad'));
    var clientinter = JSON.parse(localStorage.getItem('Clientinter'));
    var clientloss = JSON.parse(localStorage.getItem('Clientloss'));

    if (scre_schema == null || scre_schema == '') {
      this.scorearrys_asc[0] = [];
    }

    if (scorename == null || scorename == undefined || scorename == '' || scorename.length == 0) {
      this.scorearrys[0] = [];
    }

    if (subids == null) {
      this.subarrys[0] = [];
    }

    this.anArrays[0] = [];

    if (my_object != undefined || my_object != null) {
      var trdtype = JSON.parse(localStorage.getItem('tradetype'));
      var trdtypeval = JSON.parse(localStorage.getItem('tradetypeval'));
      var dirarry = JSON.parse(localStorage.getItem('Directoryarray'));
      var tblsrchdata = JSON.parse(localStorage.getItem('tblsrchdata'));
      var deccolarry = JSON.parse(localStorage.getItem('Decisioncolarray'));
      var decapprovdarry = JSON.parse(localStorage.getItem('Decisionapprvd'));
      var decapprvarry = JSON.parse(localStorage.getItem('Decisionapprv'));
      var decbookdarry = JSON.parse(localStorage.getItem('Decisionbookd'));
      var decdlnarry = JSON.parse(localStorage.getItem('Decisiondecl'));
      var Hiervalsrc = JSON.parse(localStorage.getItem('Hiervalsrc'));

      if (my_object['company_type'] == 'client table') {
        this.datasrc_check1 = true;
        this.datasrc_check2 = false;
        //tabs to be enabled
        this.clienttab_disable = false;
        this.ascendtab_disable = true;
        this.infertab_disable = true;
        this.scretab_disable = false;

        this.disable_db = false;
        this.disable_cmpny = true;
        this.mandatory_req = false;
        this.subarrys[0] = [];

        this.DirName = dirarry;
        this.Dirid = my_object['directory'];

        this.uniqcol = deccolarry;
        this.datecol = deccolarry;
        this.custcol = deccolarry;
        this.dec_type = [];
        this.dec_type = decapprovdarry;

        this.dec_type_booked = [];
        this.dec_type_booked = decbookdarry;
        this.dec_type_approvd = [];
        this.dec_type_approvd = decapprvarry;
        this.dec_type_decl = [];
        this.dec_type_decl = decdlnarry;

        this.tblsrchdata = [];
        this.tblsrchdata = tblsrchdata;
        this.subarrys[0] = [];

        this.dropdownList_trdval = Hiervalsrc;

        this.client_company_name = my_object['company_name'];
        this.Tblid = my_object['tbl_name'];
        this.appln_date_model = my_object['appln_date_col'];
        this.Uniqcustmodel = my_object['uniquecust_col'];
        this.date_format_model = my_object['appln_dt_format'];
        this.dec_col_model = my_object['appln_dec_col'];
        this.book_model = my_object['booked'];
        this.dec_model = my_object['dec_type'];
        this.arrpvd_not_model = my_object['apprvd_bookd'];
        this.decline_model = my_object['declined'];
        this.per_col_model = my_object['performance_col'];
        this.trd_col_model = my_object['trade_col'];
        this.StartDate = my_object['startdateorg'];
        this.EndDate = my_object['endateorg'];
        this.good_model = my_object['good'];
        this.inter_model = my_object['indeteminant'];
        this.bad_model = my_object['bad'];
        this.loss_model = my_object['loss'];
        this.Hashcustmodel = my_object['hash_pin'];
        this.Scores = my_object['predefined_scores'];

        this.good_defn = clientgood;
        this.bad_defn = clientbad;
        this.inter_defn = clientinter;
        this.loss_defn = clientloss;
        this.ClientStartDate();

        if (trdtype != undefined && trdtype != null && trdtype.length > 0) {
          this.anArrays = trdtype;
          this.count = this.anArrays.length;
        }

        if (trdtypeval != undefined || trdtypeval != null) {
          for (var i = 0; i < trdtypeval.length; i++) {
            this.Trdval.push(trdtypeval[i]);
            this.port_arrys.push(trdtype[i]);
          }
        }

        if (scorename != undefined || scorename != null) {
          for (var i = 0; i < scorename.length; i++) {
            this.scorenameid.push(scorename[i]);
            this.scorearrys.push(scorename[i]);
            this.scorecolid.push(scorecolid[i]);
            this.vallow.push(vallow[i]);
            this.valhigh.push(valhigh[i]);
            this.reverse.push(reverse[i]);
          }
        }
      } else {
        this.datasrc_check1 = false;
        this.datasrc_check2 = true;
        this.disable_cmpny = false;

        //tabs to be enabled
        this.clienttab_disable = true;
        this.ascendtab_disable = false;
        this.infertab_disable = false;
        this.scretab_disable = false;

        this.mandatory_req_type2 = false;
        this.scorearrys[0] = [];

        this.disable_db = true;
        this.BaseMonth = my_object['per_snap_mnth'];
        this.BaseYear = my_object['per_snap_year'];
        this.perfwindmodel = my_object['per_wind'];
        this.Ascend_StartDate = my_object['startdateasc'];
        this.Ascend_EndDate = my_object['endateorgasc'];
        this.Publicrec = my_object['public_rec'];
        this.Collectionrec = my_object['collection_rec'];

        this.AscendStartDate();

        this.good_model_ascend = my_object['good'];
        this.inter_model_ascend = my_object['indeteminant'];
        this.bad_model_ascend = my_object['bad'];
        this.loss_model_ascend = my_object['loss'];

        if (subids != undefined || subids != null) {
          for (var i = 0; i < subids.length; i++) {
            this.subid.push(subids[i]);
            this.subarrys.push(subids[i]);
            this.ascend_company_name.push(asc_companyname[i]);
          }
        }
      }

      this.date_arch_model = my_object['archivedt'];

      if (scre_schema != undefined || scre_schema != null || scre_schema != '') {
        for (var k = 0; k < scre_schema.length; k++) {
          this.scorearrys_asc.push(scre_schema[k]);
          this.scoreschema_asc.push(scre_schema[k]);
          this.scoretabnameid.push(scre_name[k]);
          this.scoretable_asc.push(scre_table[k]);
          this.scorecolid_asc.push(scre_column[k]);
          this.vallow_asc.push(scre_vallow[k]);
          this.valhigh_asc.push(scre_valhigh[k]);
          this.reverse_asc.push(scre_rev[k]);
        }

        for (var j = 0; j < scre_tbldata.length; j++) {
          this.scre_tbl[j] = scre_tbldata[j];
        }

        for (var l = 0; l < scre_columndata.length; l++) {
          this.scre_col[l] = scre_columndata[l];
        }
      }

      this.validat_model = my_object['validate'];
    }

    this.ascendsrch = [
      {
        item_id_srch: 'premier_1_2',
        item_text_srch: 'premier_1_2'
      },
      {
        item_id_srch: 'public_record',
        item_text_srch: 'public_record'
      },
      {
        item_id_srch: 'bankruptcy_plus',
        item_text_srch: 'bankruptcy_plus'
      },
      {
        item_id_srch: 'trended_3d',
        item_text_srch: 'trended_3d'
      }
    ];

    this.atgsrch = [
      {
        item_id_srch: 'inquiry_company',
        item_text_srch: 'inquiry_company'
      },
      {
        item_id_srch: 'tin_company',
        item_text_srch: 'trade_life_test'
      },
      {
        item_id_srch: 'trade_life_test',
        item_text_srch: 'trade_life_test'
      },
      {
        item_id_srch: 'vantage_3_new',
        item_text_srch: 'vantage_3_new'
      }
    ];
    this.s99_grpsrch = [
      {
        item_id_srch: 'ca_penfed_bcus_c57540a_mt',
        item_text_srch: 'ca_penfed_bcus_c57540a_mt'
      },
      {
        item_id_srch: 'ca_penfed_bcus_c53012a_mt',
        item_text_srch: 'ca_penfed_bcus_c53012a_mt'
      },
      {
        item_id_srch: 'ca_penfed_bcus_c62542a_mt',
        item_text_srch: 'ca_penfed_bcus_c62542a_mt'
      },
      {
        item_id_srch: 'ca_penfed_bcus_c56422a_mt',
        item_text_srch: 'ca_penfed_bcus_c56422a_mt'
      }
    ];

    this.dropdownSettingssrch = {
      singleSelection: true,
      idField: 'item_id_srch',
      textField: 'item_text_srch',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: true
    };

    this.table_col[0] = [];

    this.dropdownSettings_scretbl = {
      singleSelection: true,
      idField: 'item_id_scretbl',
      textField: 'item_text_scretbl',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: true
    };

    this.TableName = this.ascend_lite_output_name;

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.dropdownSettings_bookd = {
      singleSelection: false,
      idField: 'item_id_book',
      textField: 'item_text_book',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };
    this.dropdownSettings_apprvd = {
      singleSelection: false,
      idField: 'item_id_apprvd',
      textField: 'item_text_apprvd',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };
    this.dropdownSettings_declnd = {
      singleSelection: false,
      idField: 'item_id_decl',
      textField: 'item_text_decl',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.goodSettings = {
      singleSelection: false,
      idField: 'item_id_gd',
      textField: 'item_text_gd',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.good_defn_scre = [
      {
        item_id_gd: 'Exclusion',
        item_text_gd: 'Exclusion'
      },
      {
        item_id_gd: 'Current',
        item_text_gd: 'Current'
      },
      {
        item_id_gd: '30 Days Delinquent',
        item_text_gd: '30 Days Delinquent'
      },
      {
        item_id_gd: '60 Days Delinquent',
        item_text_gd: '60 Days Delinquent'
      },
      {
        item_id_gd: '90 Days Delinquent',
        item_text_gd: '90 Days Delinquent'
      },
      {
        item_id_gd: '120 Days Delinquent',
        item_text_gd: '120 Days Delinquent'
      },
      {
        item_id_gd: '150 Days Delinquent',
        item_text_gd: '150 Days Delinquent'
      },
      {
        item_id_gd: '180 Days Delinquent',
        item_text_gd: '180 Days Delinquent'
      },
      {
        item_id_gd: '2 times 30 Days Delinquent',
        item_text_gd: '2 times 30 Days Delinquent'
      },
      {
        item_id_gd: '3 times 30 Days Delinquent',
        item_text_gd: '3 times 30 Days Delinquent'
      },
      {
        item_id_gd: 'Status Unknown',
        item_text_gd: 'Status Unknown'
      },
      {
        item_id_gd: 'Loss',
        item_text_gd: 'Loss'
      },
      {
        item_id_gd: 'BK',
        item_text_gd: 'BK'
      },
      {
        item_id_gd: 'Public Record Bk',
        item_text_gd: 'Public Record Bk'
      },
      {
        item_id_gd: 'Derog',
        item_text_gd: 'Derog'
      }
    ];
    this.goodSettings_scre = {
      singleSelection: false,
      idField: 'item_id_gd',
      textField: 'item_text_gd',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.interSettings = {
      singleSelection: false,
      idField: 'item_id_inter',
      textField: 'item_text_inter',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.inter_defn_scre = [
      {
        item_id_inter: 'Exclusion',
        item_text_inter: 'Exclusion'
      },
      {
        item_id_inter: 'Current',
        item_text_inter: 'Current'
      },
      {
        item_id_inter: '30 Days Delinquent',
        item_text_inter: '30 Days Delinquent'
      },
      {
        item_id_inter: '60 Days Delinquent',
        item_text_inter: '60 Days Delinquent'
      },
      {
        item_id_inter: '90 Days Delinquent',
        item_text_inter: '90 Days Delinquent'
      },
      {
        item_id_inter: '120 Days Delinquent',
        item_text_inter: '120 Days Delinquent'
      },
      {
        item_id_inter: '150 Days Delinquent',
        item_text_inter: '150 Days Delinquent'
      },
      {
        item_id_inter: '180 Days Delinquent',
        item_text_inter: '180 Days Delinquent'
      },
      {
        item_id_inter: '2 times 30 Days Delinquent',
        item_text_inter: '2 times 30 Days Delinquent'
      },
      {
        item_id_inter: '3 times 30 Days Delinquent',
        item_text_inter: '3 times 30 Days Delinquent'
      },
      {
        item_id_inter: 'Status Unknown',
        item_text_inter: 'Status Unknown'
      },
      {
        item_id_inter: 'Loss',
        item_text_inter: 'Loss'
      },
      {
        item_id_inter: 'BK',
        item_text_inter: 'BK'
      },
      {
        item_id_inter: 'Public Record Bk',
        item_text_inter: 'Public Record Bk'
      },
      {
        item_id_inter: 'Derog',
        item_text_inter: 'Derog'
      }
    ];
    this.interSettings_scre = {
      singleSelection: false,
      idField: 'item_id_inter',
      textField: 'item_text_inter',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.badSettings = {
      singleSelection: false,
      idField: 'item_id_bd',
      textField: 'item_text_bd',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.bad_defn_scre = [
      {
        item_id_bd: 'Exclusion',
        item_text_bd: 'Exclusion'
      },
      {
        item_id_bd: 'Current',
        item_text_bd: 'Current'
      },
      {
        item_id_bd: '30 Days Delinquent',
        item_text_bd: '30 Days Delinquent'
      },
      {
        item_id_bd: '60 Days Delinquent',
        item_text_bd: '60 Days Delinquent'
      },
      {
        item_id_bd: '90 Days Delinquent',
        item_text_bd: '90 Days Delinquent'
      },
      {
        item_id_bd: '120 Days Delinquent',
        item_text_bd: '120 Days Delinquent'
      },
      {
        item_id_bd: '150 Days Delinquent',
        item_text_bd: '150 Days Delinquent'
      },
      {
        item_id_bd: '180 Days Delinquent',
        item_text_bd: '180 Days Delinquent'
      },
      {
        item_id_bd: '2 times 30 Days Delinquent',
        item_text_bd: '2 times 30 Days Delinquent'
      },
      {
        item_id_bd: '3 times 30 Days Delinquent',
        item_text_bd: '3 times 30 Days Delinquent'
      },
      {
        item_id_bd: 'Status Unknown',
        item_text_bd: 'Status Unknown'
      },
      {
        item_id_bd: 'Loss',
        item_text_bd: 'Loss'
      },
      {
        item_id_bd: 'BK',
        item_text_bd: 'BK'
      },
      {
        item_id_bd: 'Public Record Bk',
        item_text_bd: 'Public Record Bk'
      },
      {
        item_id_bd: 'Derog',
        item_text_bd: 'Derog'
      }
    ];
    this.badSettings_scre = {
      singleSelection: false,
      idField: 'item_id_bd',
      textField: 'item_text_bd',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.LossSettings = {
      singleSelection: false,
      idField: 'item_id_los',
      textField: 'item_text_los',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.loss_defn_scre = [
      {
        item_id_los: 'Exclusion',
        item_text_los: 'Exclusion'
      },
      {
        item_id_los: 'Current',
        item_text_los: 'Current'
      },
      {
        item_id_los: '30 Days Delinquent',
        item_text_los: '30 Days Delinquent'
      },
      {
        item_id_los: '60 Days Delinquent',
        item_text_los: '60 Days Delinquent'
      },
      {
        item_id_los: '90 Days Delinquent',
        item_text_los: '90 Days Delinquent'
      },
      {
        item_id_los: '120 Days Delinquent',
        item_text_los: '120 Days Delinquent'
      },
      {
        item_id_los: '150 Days Delinquent',
        item_text_los: '150 Days Delinquent'
      },
      {
        item_id_los: '180 Days Delinquent',
        item_text_los: '180 Days Delinquent'
      },
      {
        item_id_los: '2 times 30 Days Delinquent',
        item_text_los: '2 times 30 Days Delinquent'
      },
      {
        item_id_los: '3 times 30 Days Delinquent',
        item_text_los: '3 times 30 Days Delinquent'
      },
      {
        item_id_los: 'Status Unknown',
        item_text_los: 'Status Unknown'
      },
      {
        item_id_los: 'Loss',
        item_text_los: 'Loss'
      },
      {
        item_id_los: 'BK',
        item_text_los: 'BK'
      },
      {
        item_id_los: 'Public Record Bk',
        item_text_los: 'Public Record Bk'
      },
      {
        item_id_los: 'Derog',
        item_text_los: 'Derog'
      }
    ];

    this.LossSettings_scre = {
      singleSelection: false,
      idField: 'item_id_los',
      textField: 'item_text_los',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.new_ex = [
      {
        item_id_nex: 'New',
        item_text_nex: 'New'
      },
      {
        item_id_nex: 'Existing',
        item_text_nex: 'Existing'
      }
    ];
    this.new_settings = {
      singleSelection: false,
      idField: 'item_id_nex',
      textField: 'item_text_nex',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.dropdownSettings_score = {
      singleSelection: false,
      idField: 'item_id_score',
      textField: 'item_text_score',
      selectAllText: 'All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: true
      // allowSearchFilter: true
    };

    this.dropdownSettings_trdval = {
      singleSelection: false,
      idField: 'item_id_trd',
      textField: 'item_text_trd',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };
  }

  openPanel() {
    this.hgt = false;
  }

  ClosePanel() {
    this.hgt = true;
  }

  onDecTypeSelect(event: any) {
    this.dec_type_booked = [];
    this.dec_type_approvd = [];
    this.dec_type_decl = [];

    for (var i = 0; i < this.dec_model.length; i++) {
      this.dec_type_booked.push({
        item_id_book: this.dec_model[i]['item_id'],
        item_text_book: this.dec_model[i]['item_id']
      });
      this.dec_type_approvd.push({
        item_id_apprvd: this.dec_model[i]['item_id'],
        item_text_apprvd: this.dec_model[i]['item_id']
      });
      this.dec_type_decl.push({
        item_id_decl: this.dec_model[i]['item_id'],
        item_text_decl: this.dec_model[i]['item_id']
      });
    }
  }

  onDecTypeDeSelect(event: any) {
    this.dec_type_booked = [];
    this.dec_type_approvd = [];
    this.dec_type_decl = [];

    if (this.dec_model.length <= 0) {
      for (var i = 0; i < this.dec_type.length; i++) {
        this.dec_type_booked.push({
          item_id_book: this.dec_type[i]['item_id'],
          item_text_book: this.dec_type[i]['item_id']
        });
        this.dec_type_approvd.push({
          item_id_apprvd: this.dec_type[i]['item_id'],
          item_text_apprvd: this.dec_type[i]['item_id']
        });
        this.dec_type_decl.push({
          item_id_decl: this.dec_type[i]['item_id'],
          item_text_decl: this.dec_type[i]['item_id']
        });
      }
    } else {
      for (var i = 0; i < this.dec_model.length; i++) {
        this.dec_type_booked.push({
          item_id_book: this.dec_model[i]['item_id'],
          item_text_book: this.dec_model[i]['item_id']
        });
        this.dec_type_approvd.push({
          item_id_apprvd: this.dec_model[i]['item_id'],
          item_text_apprvd: this.dec_model[i]['item_id']
        });
        this.dec_type_decl.push({
          item_id_decl: this.dec_model[i]['item_id'],
          item_text_decl: this.dec_model[i]['item_id']
        });
      }
    }
  }

  onBookedSelect(event: any) {
    this.dec_type_approvd.splice(
      this.dec_type_approvd.findIndex(item => item.item_id_apprvd === event['item_id_book']),
      1
    );
    this.dec_type_approvd = [...this.dec_type_approvd];

    this.dec_type_decl.splice(
      this.dec_type_decl.findIndex(item => item.item_id_decl === event['item_id_book']),
      1
    );
    this.dec_type_decl = [...this.dec_type_decl];
  }

  onBookedDeSelect(event: any) {
    this.dec_type_approvd.push({
      item_id_approvd: event['item_id_book'],
      item_text_apprvd: event['item_id_book']
    });
    this.dec_type_approvd = [...this.dec_type_approvd];

    this.dec_type_decl.push({
      item_id_decl: event['item_id_book'],
      item_text_decl: event['item_id_book']
    });
    this.dec_type_decl = [...this.dec_type_decl];
  }
  onApprovdSelect(event: any) {
    this.dec_type_booked.splice(
      this.dec_type_booked.findIndex(item => item.item_id_book === event['item_id_apprvd']),
      1
    );
    this.dec_type_booked = [...this.dec_type_booked];

    this.dec_type_decl.splice(
      this.dec_type_decl.findIndex(item => item.item_id_decl === event['item_id_apprvd']),
      1
    );
    this.dec_type_decl = [...this.dec_type_decl];
  }

  onApprovdDeSelect(event: any) {
    this.dec_type_booked.push({
      item_id_book: event['item_id_apprvd'],
      item_text_book: event['item_id_apprvd']
    });
    this.dec_type_booked = [...this.dec_type_booked];

    this.dec_type_decl.push({
      item_id_decl: event['item_id_apprvd'],
      item_text_decl: event['item_id_apprvd']
    });
    this.dec_type_decl = [...this.dec_type_decl];
  }

  onDeclinedSelect(event: any) {
    this.dec_type_booked.splice(
      this.dec_type_booked.findIndex(item => item.item_id_book === event['item_id_decl']),
      1
    );
    this.dec_type_booked = [...this.dec_type_booked];

    this.dec_type_approvd.splice(
      this.dec_type_approvd.findIndex(item => item.item_id_apprvd === event['item_id_decl']),
      1
    );
    this.dec_type_approvd = [...this.dec_type_approvd];
  }

  onDeclinedDeSelect(event: any) {
    this.dec_type_booked.push({
      item_id_book: event['item_id_decl'],
      item_text_book: event['item_id_decl']
    });
    this.dec_type_booked = [...this.dec_type_booked];

    this.dec_type_approvd.push({
      item_id_apprvd: event['item_id_decl'],
      item_text_apprvd: event['item_id_decl']
    });
    this.dec_type_approvd = [...this.dec_type_approvd];
  }

  onGoodSelectDefn(event: any) {
    this.bad_defn.splice(
      this.bad_defn.findIndex(item => item.item_id_bd === event['item_id_gd']),
      1
    );
    this.bad_defn = [...this.bad_defn];

    this.inter_defn.splice(
      this.inter_defn.findIndex(item => item.item_id_inter === event['item_id_gd']),
      1
    );
    this.inter_defn = [...this.inter_defn];

    this.loss_defn.splice(
      this.loss_defn.findIndex(item => item.item_id_los === event['item_id_gd']),
      1
    );
    this.loss_defn = [...this.loss_defn];
  }

  onGoodDeSelectDefn(event: any) {
    this.bad_defn.push({
      item_id_bd: event['item_id_gd'],
      item_text_bd: event['item_id_gd']
    });
    this.bad_defn = [...this.bad_defn];

    this.inter_defn.push({
      item_id_inter: event['item_id_gd'],
      item_text_inter: event['item_id_gd']
    });
    this.inter_defn = [...this.inter_defn];

    this.loss_defn.push({
      item_id_los: event['item_id_gd'],
      item_text_los: event['item_id_gd']
    });
    this.loss_defn = [...this.loss_defn];
  }

  onGoodSelectDefn_Scre(event: any) {
    this.bad_defn_scre.splice(
      this.bad_defn_scre.findIndex(item => item.item_id_bd === event['item_id_gd']),
      1
    );
    this.bad_defn_scre = [...this.bad_defn_scre];

    this.inter_defn_scre.splice(
      this.inter_defn_scre.findIndex(item => item.item_id_inter === event['item_id_gd']),
      1
    );
    this.inter_defn_scre = [...this.inter_defn_scre];

    this.loss_defn_scre.splice(
      this.loss_defn_scre.findIndex(item => item.item_id_los === event['item_id_gd']),
      1
    );
    this.loss_defn_scre = [...this.loss_defn_scre];
  }

  onGoodDeSelectDefn_Scre(event: any) {
    this.bad_defn_scre.push({
      item_id_bd: event['item_id_gd'],
      item_text_bd: event['item_id_gd']
    });
    this.bad_defn_scre = [...this.bad_defn_scre];

    this.inter_defn_scre.push({
      item_id_inter: event['item_id_gd'],
      item_text_inter: event['item_id_gd']
    });
    this.inter_defn_scre = [...this.inter_defn_scre];

    this.loss_defn_scre.push({
      item_id_los: event['item_id_gd'],
      item_text_los: event['item_id_gd']
    });
    this.loss_defn_scre = [...this.loss_defn_scre];
  }

  onInterSelectDefn(event: any) {
    this.good_defn.splice(
      this.good_defn.findIndex(item => item.item_id_gd === event['item_id_inter']),
      1
    );
    this.good_defn = [...this.good_defn];

    this.bad_defn.splice(
      this.bad_defn.findIndex(item => item.item_id_bd === event['item_id_inter']),
      1
    );
    this.bad_defn = [...this.bad_defn];

    this.loss_defn.splice(
      this.loss_defn.findIndex(item => item.item_id_los === event['item_id_inter']),
      1
    );
    this.loss_defn = [...this.loss_defn];
  }

  onInterDeSelectDefn(event: any) {
    this.good_defn.push({
      item_id_gd: event['item_id_inter'],
      item_text_gd: event['item_id_inter']
    });
    this.good_defn = [...this.good_defn];

    this.bad_defn.push({
      item_id_bd: event['item_id_inter'],
      item_text_bd: event['item_id_inter']
    });
    this.bad_defn = [...this.bad_defn];

    this.loss_defn.push({
      item_id_los: event['item_id_inter'],
      item_text_los: event['item_id_inter']
    });
    this.loss_defn = [...this.loss_defn];
  }

  onInterSelectDefn_Scre(event: any) {
    this.good_defn_scre.splice(
      this.good_defn_scre.findIndex(item => item.item_id_gd === event['item_id_inter']),
      1
    );
    this.good_defn_scre = [...this.good_defn_scre];

    this.bad_defn_scre.splice(
      this.bad_defn_scre.findIndex(item => item.item_id_bd === event['item_id_inter']),
      1
    );
    this.bad_defn_scre = [...this.bad_defn_scre];

    this.loss_defn_scre.splice(
      this.loss_defn_scre.findIndex(item => item.item_id_los === event['item_id_inter']),
      1
    );
    this.loss_defn_scre = [...this.loss_defn_scre];
  }

  onInterDeSelectDefn_Scre(event: any) {
    this.good_defn_scre.push({
      item_id_gd: event['item_id_inter'],
      item_text_gd: event['item_id_inter']
    });
    this.good_defn_scre = [...this.good_defn_scre];

    this.bad_defn_scre.push({
      item_id_bd: event['item_id_inter'],
      item_text_bd: event['item_id_inter']
    });
    this.bad_defn_scre = [...this.bad_defn_scre];

    this.loss_defn_scre.push({
      item_id_los: event['item_id_inter'],
      item_text_los: event['item_id_inter']
    });
    this.loss_defn_scre = [...this.loss_defn_scre];
  }

  onBadSelectDefn(event: any) {
    this.good_defn.splice(
      this.good_defn.findIndex(item => item.item_id_gd === event['item_id_bd']),
      1
    );
    this.good_defn = [...this.good_defn];

    this.inter_defn.splice(
      this.inter_defn.findIndex(item => item.item_id_inter === event['item_id_bd']),
      1
    );
    this.inter_defn = [...this.inter_defn];

    this.loss_defn.splice(
      this.loss_defn.findIndex(item => item.item_id_los === event['item_id_bd']),
      1
    );
    this.loss_defn = [...this.loss_defn];
  }
  onBadDeSelectDefn(event: any) {
    this.good_defn.push({
      item_id_gd: event['item_id_bd'],
      item_text_gd: event['item_id_bd']
    });
    this.good_defn = [...this.good_defn];

    this.inter_defn.push({
      item_id_inter: event['item_id_bd'],
      item_text_inter: event['item_id_bd']
    });
    this.inter_defn = [...this.inter_defn];

    this.loss_defn.push({
      item_id_los: event['item_id_bd'],
      item_text_los: event['item_id_bd']
    });
    this.loss_defn = [...this.loss_defn];
  }

  onBadSelectDefn_Scre(event: any) {
    this.good_defn_scre.splice(
      this.good_defn_scre.findIndex(item => item.item_id_gd === event['item_id_bd']),
      1
    );
    this.good_defn_scre = [...this.good_defn_scre];

    this.inter_defn_scre.splice(
      this.inter_defn_scre.findIndex(item => item.item_id_inter === event['item_id_bd']),
      1
    );
    this.inter_defn_scre = [...this.inter_defn_scre];

    this.loss_defn_scre.splice(
      this.loss_defn_scre.findIndex(item => item.item_id_los === event['item_id_bd']),
      1
    );
    this.loss_defn_scre = [...this.loss_defn_scre];
  }

  onBadDeSelectDefn_scre(event: any) {
    this.good_defn_scre.push({
      item_id_gd: event['item_id_bd'],
      item_text_gd: event['item_id_bd']
    });
    this.good_defn_scre = [...this.good_defn_scre];

    this.inter_defn_scre.push({
      item_id_inter: event['item_id_bd'],
      item_text_inter: event['item_id_bd']
    });
    this.inter_defn_scre = [...this.inter_defn_scre];

    this.loss_defn_scre.push({
      item_id_los: event['item_id_bd'],
      item_text_los: event['item_id_bd']
    });
    this.loss_defn_scre = [...this.loss_defn_scre];
  }

  onLossSelectDefn(event: any) {
    this.good_defn.splice(
      this.good_defn.findIndex(item => item.item_id_gd === event['item_id_los']),
      1
    );
    this.good_defn = [...this.good_defn];

    this.inter_defn.splice(
      this.inter_defn.findIndex(item => item.item_id_inter === event['item_id_los']),
      1
    );
    this.inter_defn = [...this.inter_defn];

    this.bad_defn.splice(
      this.bad_defn.findIndex(item => item.item_id_bd === event['item_id_los']),
      1
    );
    this.bad_defn = [...this.bad_defn];
  }

  onLossDeSelectDefn(event: any) {
    this.good_defn.push({
      item_id_gd: event['item_id_los'],
      item_text_gd: event['item_id_los']
    });
    this.good_defn = [...this.good_defn];

    this.inter_defn.push({
      item_id_inter: event['item_id_los'],
      item_text_inter: event['item_id_los']
    });
    this.inter_defn = [...this.inter_defn];

    this.bad_defn.push({
      item_id_bd: event['item_id_los'],
      item_text_bd: event['item_id_los']
    });
    this.bad_defn = [...this.bad_defn];
  }

  onLossSelectDefn_Scre(event: any) {
    this.good_defn_scre.splice(
      this.good_defn_scre.findIndex(item => item.item_id_gd === event['item_id_los']),
      1
    );
    this.good_defn_scre = [...this.good_defn_scre];

    this.inter_defn_scre.splice(
      this.inter_defn_scre.findIndex(item => item.item_id_inter === event['item_id_los']),
      1
    );
    this.inter_defn_scre = [...this.inter_defn_scre];

    this.bad_defn_scre.splice(
      this.bad_defn_scre.findIndex(item => item.item_id_bd === event['item_id_los']),
      1
    );
    this.bad_defn_scre = [...this.bad_defn_scre];
  }

  onLossDeSelectDefn_Scre(event: any) {
    this.good_defn_scre.push({
      item_id_gd: event['item_id_los'],
      item_text_gd: event['item_id_los']
    });
    this.good_defn_scre = [...this.good_defn_scre];

    this.inter_defn_scre.push({
      item_id_inter: event['item_id_los'],
      item_text_inter: event['item_id_los']
    });
    this.inter_defn_scre = [...this.inter_defn_scre];

    this.bad_defn_scre.push({
      item_id_bd: event['item_id_los'],
      item_text_bd: event['item_id_los']
    });
    this.bad_defn_scre = [...this.bad_defn_scre];
  }

  /*Api calls*/
  //get directories
  Getdir() {
    this.homeservice.GetDirectories().subscribe((apiresponse: any) => {
      this.DirName = apiresponse['directory_list'];
      this.schema_col = apiresponse['directory_list'];
    });
  }

  Gettable(data: any) {
    this.tabledata = [];
    this.homeservice.Get_table(data).subscribe((apiresponse: any) => {
      for (var i = 0; i < apiresponse['table_list'].length; i++) {
        this.tabledata.push({
          item_id_srch: apiresponse['table_list'][i],
          item_text_srch: apiresponse['table_list'][i]
        });

        this.tblsrchdata = this.tabledata;
      }
    });
  }

  onFilterChange(event: any) {
    var n = event.length;
    var data = {
      directory_name: this.Dirid,
      q: event
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    if (n >= 4) {
      this.homeservice.SearchQuery(data).subscribe((apiresponse: any) => {
        this.tblsrchdata = [];

        this.tabledata = [];

        for (var i = 0; i < apiresponse['table_list'].length; i++) {
          this.tabledata.push({
            item_id_srch: apiresponse['table_list'][i],
            item_text_srch: apiresponse['table_list'][i]
          });

          this.tblsrchdata = this.tabledata;
        }
      });
    }
  }

  OnTablechange(event: any) {
    var data = {
      directory_name: this.Dirid,
      table_name: this.Tblid[0]['item_id_srch']
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    this.Getdec_perfmcol(data);
  }

  Getdec_perfmcol(data: any) {
    this.uniqcol = [];
    this.datecol = [];
    this.custcol = [];

    this.homeservice.Getdecperfmcol(data).subscribe((apiresponse: any) => {
      this.uniqcol = apiresponse['record_list'];
      this.datecol = apiresponse['record_list'];
      this.custcol = apiresponse['record_list'];
    });
  }

  OnDecColchange() {
    var data = {
      directory_name: this.Dirid,
      table_name: this.Tblid[0]['item_id_srch'],
      col_name: this.dec_col_model
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };
    this.Getdec_booked(data);
  }

  OnSelectchange() {
    if (this.Dirid != '' && this.Tblid.length > 0) {
    } else {
      this.toastr.error('', 'Select directory and tablename');
    }

    var data = {
      directory_name: this.Dirid,
      table_name: this.Tblid[0]['item_id_srch'],
      col_name: this.trd_col_model
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };
    this.GetHiervals(data);
  }

  Getdec_booked(data: any) {
    this.dec_type = [];
    this.dec_type_booked = [];
    this.dec_type_approvd = [];
    this.dec_type_decl = [];
    this.dec_array = [];
    var decarry_booked: any = [];
    var decarry_approvd: any = [];
    var decarryy_decl: any = [];

    this.homeservice.Getdecbookedper(data).subscribe((apiresponse: any) => {
      for (var i = 0; i < apiresponse['distinct_list'].length; i++) {
        this.dec_array.push({
          item_id: apiresponse['distinct_list'][i],
          item_text: apiresponse['distinct_list'][i]
        });
        decarry_booked.push({
          item_id_book: apiresponse['distinct_list'][i],
          item_text_book: apiresponse['distinct_list'][i]
        });
        decarry_approvd.push({
          item_id_apprvd: apiresponse['distinct_list'][i],
          item_text_apprvd: apiresponse['distinct_list'][i]
        });

        decarryy_decl.push({
          item_id_decl: apiresponse['distinct_list'][i],
          item_text_decl: apiresponse['distinct_list'][i]
        });

        this.dec_type = this.dec_array;
        this.dec_type_booked = decarry_booked;
        this.dec_type_approvd = decarry_approvd;
        this.dec_type_decl = decarryy_decl;
      }
    });
  }

  Performance_change() {
    this.good_defn = [];
    this.inter_defn = [];
    this.bad_defn = [];
    this.loss_defn = [];
    var good_arry: any = [];
    var bad_arry: any = [];
    var inter_arry: any = [];
    var loss_arry: any = [];

    var data = {
      directory_name: this.Dirid,
      table_name: this.Tblid[0]['item_id_srch'],
      col_name: this.per_col_model
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    this.homeservice.Getdecbookedper(data).subscribe((apiresponse: any) => {
      for (var i = 0; i < apiresponse['distinct_list'].length; i++) {
        good_arry.push({
          item_id_gd: apiresponse['distinct_list'][i],
          item_text_gd: apiresponse['distinct_list'][i]
        });
        bad_arry.push({
          item_id_bd: apiresponse['distinct_list'][i],
          item_text_bd: apiresponse['distinct_list'][i]
        });
        inter_arry.push({
          item_id_inter: apiresponse['distinct_list'][i],
          item_text_inter: apiresponse['distinct_list'][i]
        });

        loss_arry.push({
          item_id_los: apiresponse['distinct_list'][i],
          item_text_los: apiresponse['distinct_list'][i]
        });

        this.good_defn = good_arry;
        this.inter_defn = inter_arry;
        this.bad_defn = bad_arry;
        this.loss_defn = loss_arry;
      }
    });
  }

  GetHiervals(data: any) {
    this.hier_arrayval = [];
    // console.log(index);

    this.homeservice.Getdecbookedper(data).subscribe((apiresponse: any) => {
      for (var i = 0; i < apiresponse['distinct_list'].length; i++) {
        this.hier_arrayval.push({
          item_id_trd: apiresponse['distinct_list'][i],
          item_text_trd: apiresponse['distinct_list'][i]
        });
      }
      this.dropdownList_trdval = this.hier_arrayval;
    });
  }

  /*Api calls*/

  //reject dropdown change

  Dirchange() {
    this.tblsrchdata = [];
    this.Tblid = [];

    if (this.Dirid != '' && this.Tblid.length > 0) {
      this.enableportype = false;
    } else {
      this.enableportype = true;
    }
    var data = {
      directory_name: this.Dirid
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    this.Gettable(data);
  }

  // Getschema() {
  //   this.homeservice.GetDirectories().subscribe((apiresponse: any) => {
  //     this.schema_col = apiresponse['directory_list'];
  //   });
  // }

  Schemachange(index: any) {
    var data = {
      directory_name: this.scoreschema_asc[index]
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    this.Gescre_table(data, index);
  }

  Gescre_table(schemaid: any, index: any) {
    let tbldata_scre: any = [];

    this.scre_tbl[index] = [];
    this.homeservice.Get_table(schemaid).subscribe((apiresponse: any) => {
      for (var i = 0; i < apiresponse.table_list.length; i++) {
        tbldata_scre.push({
          item_id_scretbl: apiresponse['table_list'][i],
          item_text_scretbl: apiresponse['table_list'][i]
        });

        this.scre_tbl[index] = tbldata_scre;
      }
    });
  }

  OnScreTablechange(event: any, index: any) {
    var data = {
      directory_name: this.scoreschema_asc[index],
      table_name: this.scoretable_asc[index][0]['item_id_scretbl']
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    this.Get_Screcol(data, index);
  }

  Get_Screcol(data: any, index: any) {
    this.scre_col[index] = [];

    this.homeservice.Getdecperfmcol(data).subscribe((apiresponse: any) => {
      this.scre_col[index] = apiresponse['record_list'];
    });
  }

  onScretblfilter(event: any, index: any) {
    var n = event.length;
    var data = {
      directory_name: this.scoreschema_asc[index],
      q: event
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    let tbldata_scre: any = [];

    if (n >= 4) {
      this.homeservice.SearchQuery(data).subscribe((apiresponse: any) => {
        tbldata_scre = [];
        this.scre_tbl[index] = [];

        for (var i = 0; i < apiresponse['table_list'].length; i++) {
          tbldata_scre.push({
            item_id_scretbl: apiresponse['table_list'][i],
            item_text_scretbl: apiresponse['table_list'][i]
          });

          this.scre_tbl[index] = tbldata_scre;
        }
      });
    }
  }

  radiopublicChange(event: any) {}
  radiocollectionChange(event: any) {}

  Addproxy() {
    this.count = this.count + 1;

    this.anArrays.push(this.anArrays[this.count]);
    if (this.count == 9) {
      this.proxyButton = true;
    } else {
      this.proxyButton = false;
    }
  }

  Removeproxys(i: any) {
    this.count = this.count - 1;
    this.anArrays.splice(i, 1);
    if (this.count == 9) {
      this.proxyButton = true;
    } else {
      this.proxyButton = false;
    }
  }

  radioChange1(event: any) {
    if (event.value == '1') {
      this.datasrc_check1 = true;
      this.datasrc_check2 = false;
      this.disable_db = false;
      this.disable_cmpny = true;
      this.mandatory_req = false;
      this.mandatory_req_type2 = true;

      this.ascendtab_disable = true;
      this.infertab_disable = true;
      this.clienttab_disable = false;
      this.scretab_disable = false;
    }
  }

  radioChange2(event: any) {
    if (event.value == '2') {
      this.datasrc_check1 = false;
      this.datasrc_check2 = true;
      this.disable_db = true;
      this.disable_cmpny = false;
      this.mandatory_req = true;
      this.mandatory_req_type2 = false;
      this.companyname_mand = true;
      this.uniqcust_mand = true;
      this.appldtcol_mand = true;
      this.applndtfor_mand = true;
      this.applndeccol_mand = true;
      this.booked_mand = true;
      this.apprvdnt_mand = true;
      this.decline_mand = true;
      this.trdval_mand = true;

      this.clienttab_disable = true;
      this.ascendtab_disable = false;
      this.infertab_disable = false;
      this.scretab_disable = false;
    }
  }

  /*Common tab NAVIGATION*/

  MainToClientOrAsc() {
    if (this.datasrc_check1 == true && this.datasrc_check2 == false) {
      this.mainstatus = false;
      this.clientstatus = true;
      this.ascendtatus = false;
      this.infstatus = false;
      this.screstatus = false;

      this.clientcontent = true;
      this.inferencecontent = false;
      this.maincontent = false;
      this.ascendcontent = false;
      this.scorescontent = false;
      window.scrollBy(0, -13500);
    } else {
      this.mainstatus = false;
      this.clientstatus = false;
      this.ascendtatus = true;
      this.infstatus = false;
      this.screstatus = false;

      this.clientcontent = false;
      this.inferencecontent = false;
      this.maincontent = false;
      this.ascendcontent = true;
      this.scorescontent = false;
      window.scrollBy(0, -13500);
    }
  }

  BackToMain() {
    this.mainstatus = true;
    this.clientstatus = false;
    this.ascendtatus = false;
    this.infstatus = false;
    this.screstatus = false;

    this.clientcontent = false;
    this.inferencecontent = false;
    this.maincontent = true;
    this.ascendcontent = false;
    this.scorescontent = false;
  }

  /*Common tab NAVIGATION*/

  scre_mand: boolean = true;

  /*Client tab NAVIGATION*/

  checkIfArrayIsUnique(myArray: any) {
    return myArray.length === new Set(myArray).size;
  }

  ClientToScores() {
    var port_value: any = true;
    var port_type: any = true; //portfolio

    if (
      this.Trdval.length > 1 &&
      this.Trdval.includes(undefined) == false &&
      this.Trdval.includes('null') == false &&
      this.Trdval.includes(null) == false
    ) {
      var trdval = this.Trdval.reduce(function(arr: any, e: any) {
        return arr.concat(e);
      });

      var trdfinval: any = [];
      var trdtypefinval: any = []; //portfolio

      for (var i = 0; i < trdval.length; i++) {
        trdfinval.push(trdval[i]['item_id_trd']);
      }

      for (var i = 0; i < this.port_arrys.length; i++) {
        trdtypefinval.push(this.port_arrys[i].toLowerCase());
      } //portfolio

      port_value = this.checkIfArrayIsUnique(trdfinval);
      port_type = this.checkIfArrayIsUnique(trdtypefinval); //portfolio
    }

    if (this.mandatory_req == false && this.client_company_name.trim()) {
      this.companyname_mand = true;
    } else {
      this.companyname_mand = false;
    }

    if (this.mandatory_req == false && this.Dirid) {
      this.dir_mand = true;
    } else {
      this.dir_mand = false;
    }

    if (this.mandatory_req == false && this.Tblid.length > 0) {
      this.tblsrchmand = true;
    } else {
      this.tblsrchmand = false;
    }

    if (this.mandatory_req == false && this.Uniqcustmodel.trim()) {
      this.uniqcust_mand = true;
    } else {
      this.uniqcust_mand = false;
    }

    if (this.mandatory_req == false && this.appln_date_model) {
      this.appldtcol_mand = true;
    } else {
      this.appldtcol_mand = false;
    }

    if (this.mandatory_req == false && this.date_format_model) {
      this.applndtfor_mand = true;
    } else {
      this.applndtfor_mand = false;
    }

    if (this.mandatory_req == false && this.dec_col_model) {
      this.applndeccol_mand = true;
    } else {
      this.applndeccol_mand = false;
    }

    if (this.mandatory_req == false && this.book_model.length > 0) {
      this.booked_mand = true;
    } else {
      this.booked_mand = false;
    }

    if (this.mandatory_req == false && this.arrpvd_not_model.length > 0) {
      this.apprvdnt_mand = true;
    } else {
      this.apprvdnt_mand = false;
    }

    if (this.mandatory_req == false && this.decline_model.length > 0) {
      this.decline_mand = true;
    } else {
      this.decline_mand = false;
    }

    if (this.good_model.length > 0) {
      this.good_mand = true;
    } else {
      this.good_mand = false;
    }

    if (this.bad_model.length > 0) {
      this.bad_mand = true;
    } else {
      this.bad_mand = false;
    }

    this.scorenameid = this.scorenameid.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.scorecolid = this.scorecolid.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.vallow = this.vallow.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.valhigh = this.valhigh.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.reverse = this.reverse.filter(function(v: any) {
      return v.trim() !== '';
    });

    var screcoll = this.scre_collectionvalid(
      this.scorenameid,
      'schema',
      'table',
      this.scorecolid,
      this.vallow,
      this.valhigh,
      this.reverse,
      'client'
    );

    if (screcoll == true) {
      var low_highmand: any = this.low_highvalid(this.vallow, this.valhigh);
    }

    if (port_type == true && port_value == true) {
      //portfolio
      if (
        this.companyname_mand == true &&
        this.dir_mand == true &&
        this.tblsrchmand == true &&
        this.uniqcust_mand == true &&
        this.appldtcol_mand == true &&
        this.applndtfor_mand == true &&
        this.applndeccol_mand == true &&
        this.booked_mand == true &&
        this.apprvdnt_mand == true &&
        this.decline_mand == true &&
        this.good_mand == true &&
        this.bad_mand == true
      ) {
        if (low_highmand == true) {
          this.mainstatus = false;
          this.clientstatus = false;
          this.ascendtatus = false;
          this.infstatus = false;
          this.screstatus = true;
          this.scre_mand = true;

          this.clientcontent = false;
          this.inferencecontent = false;
          this.maincontent = false;
          this.ascendcontent = false;
          this.scorescontent = true;
          window.scrollBy(0, -13500);
        }
      } else {
        this.toastr.error('Please provide all the mandatory fields required!');
      }
    } else {
      this.toastr.error('Portfolio Type and Value needs to be unique!');
    }
  }

  /*Client tab NAVIGATION*/

  /*ASCEND TAB NAVIGATION*/
  mand_asc_stt: boolean = true;
  mand_asc_endt: boolean = true;

  AscendToInference() {
    var cmpnyname = this.ascend_company_name;
    var subscriberid = this.subid;

    var cmpy_valid = 'false';
    var sub_valid = 'false';
    var st_val = 'false';
    var end_val = 'false';

    if (cmpnyname[0] != '' && cmpnyname[0] != null && cmpnyname[0] != undefined && cmpnyname.length > 0) {
      cmpy_valid = 'true';
      this.ascendcmp_valid = true;
    } else {
      cmpy_valid = 'false';
      this.ascendcmp_valid = false;
    }

    if (subscriberid[0] != '' && subscriberid[0] != null && subscriberid[0] != undefined && subscriberid.length > 0) {
      sub_valid = 'true';
      this.ascsub_valid = true;
    } else {
      sub_valid = 'false';
      this.ascsub_valid = false;
    }

    if (this.Ascend_StartDate) {
      st_val = 'true';
      this.mand_asc_stt = true;
    } else {
      st_val = 'false';
      this.mand_asc_stt = false;
    }

    if (this.Ascend_EndDate && this.Ascend_EndDate.year != 0) {
      end_val = 'true';
      this.mand_asc_endt = true;
    } else {
      end_val = 'false';
      this.mand_asc_endt = false;
    }

    var year_mnthval = this.Enddate_mnth_year();

    if (cmpy_valid == 'true' && sub_valid == 'true' && st_val == 'true' && end_val == 'true') {
      if (year_mnthval == true) {
        this.mainstatus = false;
        this.clientstatus = false;
        this.ascendtatus = false;
        this.infstatus = true;
        this.screstatus = false;

        this.clientcontent = false;
        this.inferencecontent = true;
        this.maincontent = false;
        this.ascendcontent = false;
        this.scorescontent = false;
        window.scrollBy(0, -13500);
      }
    } else {
      this.toastr.error('Please provide all the mandatory fields required!');
    }
  }

  Enddate_mnth_year() {
    var end_year = this.Ascend_EndDate.year.toString();
    var end_month = this.Ascend_EndDate.month;
    var baseyr = this.BaseYear;
    var basemnth = this.basemonthval;

    var months = [
      {
        Jan: 1,
        Feb: 2,
        Mar: 3,
        Apr: 4,
        May: 5,
        Jun: 6,
        Jul: 7,
        Aug: 8,
        Sep: 9,
        Oct: 10,
        Nov: 11,
        Dec: 12
      }
    ];

    if (baseyr == end_year) {
      var enddatmnthcnt = end_month - 1;
      var basemntcnt = months[0][this.BaseMonth];
      if (basemntcnt >= enddatmnthcnt) {
        return true;
      } else {
        this.toastr.error('Snapshot Month must be greather than or same as End date Month');
        return false;
      }
    } else if (baseyr > end_year) {
      return true;
    } else if (end_year > baseyr) {
      this.toastr.error('Snapshot Year must be greather than or same as End date Year');
      return false;
    }
  }

  InferenceToAscend() {
    this.mainstatus = false;
    this.clientstatus = false;
    this.ascendtatus = true;
    this.infstatus = false;
    this.screstatus = false;

    this.clientcontent = false;
    this.inferencecontent = false;
    this.maincontent = false;
    this.ascendcontent = true;
    this.scorescontent = false;
    window.scrollBy(0, -13500);
  }

  InferenceToScores() {
    var gvalid = 'false';
    var bvalid = 'false';

    if (this.good_model_ascend.length > 0) {
      gvalid = 'true';
      this.asc_good_mand = true;
    } else {
      gvalid = 'false';
      this.asc_good_mand = false;
    }

    if (this.bad_model_ascend.length > 0) {
      bvalid = 'true';
      this.asc_bad_mand = true;
    } else {
      bvalid = 'false';
      this.asc_bad_mand = false;
    }

    if (gvalid == 'true' && bvalid == 'true') {
      this.mainstatus = false;
      this.clientstatus = false;
      this.ascendtatus = false;
      this.infstatus = false;
      this.screstatus = true;

      this.clientcontent = false;
      this.inferencecontent = false;
      this.maincontent = false;
      this.ascendcontent = false;
      this.scorescontent = true;
      window.scrollBy(0, -13500);
    } else {
      this.toastr.error('Please provide all the mandatory fields required!');
    }
  }

  ScoresToInferenceOrClient() {
    if (this.datasrc_check1 == true && this.datasrc_check2 == false) {
      this.mainstatus = false;
      this.clientstatus = true;
      this.ascendtatus = false;
      this.infstatus = false;
      this.screstatus = false;

      this.clientcontent = true;
      this.inferencecontent = false;
      this.maincontent = false;
      this.ascendcontent = false;
      this.scorescontent = false;
      window.scrollBy(0, -13500);
    } else {
      this.mainstatus = false;
      this.clientstatus = false;
      this.ascendtatus = false;
      this.infstatus = true;
      this.screstatus = false;

      this.clientcontent = false;
      this.inferencecontent = true;
      this.maincontent = false;
      this.ascendcontent = false;
      this.scorescontent = false;
      window.scrollBy(0, -13500);
    }
  }

  /*ASCEND TAB NAVIGATION*/

  Addsubid() {
    this.count_sub = this.count_sub + 1;
    this.subarrys.push(this.subarrys[this.count_sub]);
  }

  Removesubid(i: any) {
    // console.log(i);
    this.subarrys.splice(i, 1);
    this.subid.splice(i, 1);
  }

  Addscore() {
    this.count_scre = this.count_scre + 1;
    this.scorearrys.push(this.scorearrys[this.count_scre]);
  }

  Addscoreasc() {
    this.count_scre_asc = this.count_scre + 1;
    this.scorearrys_asc.push(this.scorearrys_asc[this.count_scre_asc]);
  }

  Removescoreasc(i: any) {
    this.scorearrys_asc.splice(i, 1);
    this.scoreschema_asc.splice(i, 1);
    this.scoretable_asc.splice(i, 1);
    this.scorenameid_asc.splice(i, 1);
    this.scorecolid_asc.splice(i, 1);
    this.vallow_asc.splice(i, 1);
    this.valhigh_asc.splice(i, 1);
    this.reverse_asc.splice(i, 1);
    this.scoretabnameid.splice(i, 1);
  }

  Removescore(i: any) {
    this.scorearrys.splice(i, 1);
    this.scorenameid.splice(i, 1);
    this.scorecolid.splice(i, 1);
    this.valhigh.splice(i, 1);
    this.vallow.splice(i, 1);
  }

  progressto90() {
    var self = this;
    setTimeout(function() {
      self.progressval = '50';
    }, 2000);

    setTimeout(function() {
      self.progressval = '70';
    }, 6000);

    setTimeout(function() {
      self.progressval = '90';
    }, 10000);
  }

  Mainab() {
    this.mainstatus = true;
    this.clientstatus = false;
    this.ascendtatus = false;
    this.infstatus = false;
    this.screstatus = false;

    this.clientcontent = false;
    this.inferencecontent = false;
    this.maincontent = true;
    this.ascendcontent = false;
    this.scorescontent = false;
  }

  Clientab() {
    this.mainstatus = false;
    this.clientstatus = true;
    this.ascendtatus = false;
    this.infstatus = false;
    this.screstatus = false;

    this.clientcontent = true;
    this.inferencecontent = false;
    this.maincontent = false;
    this.ascendcontent = false;
    this.scorescontent = false;
  }

  Ascendtab() {
    this.mainstatus = false;
    this.clientstatus = false;
    this.ascendtatus = true;
    this.infstatus = false;
    this.screstatus = false;

    this.clientcontent = false;
    this.inferencecontent = false;
    this.maincontent = false;
    this.ascendcontent = true;
    this.scorescontent = false;
  }

  Inferencetab() {
    this.AscendToInference();
  }

  Scorestab() {
    if (this.datasrc_check1 == true && this.datasrc_check2 == false) {
      this.ClientToScores();
    } else {
      this.InferenceToScores();
    }
  }

  low_highvalid(low: any, high: any) {
    var cond: any;
    var vals_bool: any = [];
    for (var i = 0; i < low.length; i++) {
      if (JSON.parse(low[i]) < JSON.parse(high[i])) {
        cond = true;
      } else {
        cond = false;
      }
      vals_bool.push(cond);
    }

    var checkife: any = vals_bool.filter((item: any) => item == false).length;

    if (checkife >= 1) {
      this.toastr.error('Please make sure that Low value is less than the High value for all scores');
      return false;
    } else {
      return true;
    }
  }

  scre_collectionvalid(screname: any, schema: any, table: any, scrcol: any, low: any, high: any, sort: any, type: any) {
    var cond: any;
    var vals_bool: any = [];

    if (type == 'scores') {
      for (var i = 0; i < screname.length; i++) {
        if (
          schema[i] != '' &&
          schema[i] != undefined &&
          schema[i] &&
          table[i] != '' &&
          table[i] != undefined &&
          table[i] &&
          scrcol[i] != '' &&
          scrcol[i] != undefined &&
          scrcol[i] &&
          low[i] != '' &&
          low[i] != undefined &&
          low[i] &&
          high[i] != '' &&
          high[i] != undefined &&
          high[i] &&
          sort[i] != '' &&
          sort[i] != undefined &&
          sort[i]
        ) {
          cond = true;
        } else {
          cond = false;
        }
        vals_bool.push(cond);
      }
    } else {
      for (var i = 0; i < screname.length; i++) {
        if (
          scrcol[i] != '' &&
          scrcol[i] != undefined &&
          scrcol[i] &&
          low[i] != '' &&
          low[i] != undefined &&
          low[i] &&
          high[i] != '' &&
          high[i] != undefined &&
          high[i] &&
          sort[i] != '' &&
          sort[i] != undefined &&
          sort[i]
        ) {
          cond = true;
        } else {
          cond = false;
        }
        vals_bool.push(cond);
      }
    }

    var checkife: any = vals_bool.filter((item: any) => item == false).length;
    if (checkife >= 1) {
      this.toastr.error('Please enter values in all fields to populate a Score ');
      return false;
    } else {
      return true;
    }
  }

  ClientStartDate() {
    var mydate = this.StartDate.year + '-' + this.StartDate.month + '-' + this.StartDate.day;

    var newDate = this.incrementDate(mydate);

    var arr = newDate.split('-');

    var clientstartdt = {
      year: parseInt(arr[0]),
      month: parseInt(arr[1]),
      day: parseInt(arr[2])
    };

    this.clientmindt = clientstartdt;
  }

  AscendStartDate() {
    var mydate = this.Ascend_StartDate.year + '-' + this.Ascend_StartDate.month + '-' + this.Ascend_StartDate.day;

    var newDate = this.incrementDate(mydate);

    var arr = newDate.split('-');

    var ascstartdt = {
      year: parseInt(arr[0]),
      month: parseInt(arr[1]),
      day: parseInt(arr[2])
    };
    this.ascmindt = ascstartdt;
  }

  incrementDate(date_str: any) {
    var date = new Date(date_str);
    var next_date: any = new Date(date.setDate(date.getDate() + 1));

    return next_date.getFullYear() + '-' + (next_date.getMonth() + 1) + '-' + next_date.getDate();
  }

  ClrClientenddt() {
    this.EndDate = {
      year: 0,
      month: 0,
      day: 0
    };
  }

  ClrAscenddt() {
    this.Ascend_EndDate = {
      year: 0,
      month: 0,
      day: 0
    };
  }

  Submit() {
    var proxyobj = {};
    var hiernworexobj = {};

    for (var i = 0; i < this.anArrays.length; i++) {
      if (this.port_arrys.length > 0) {
        proxyobj['trade_type' + (i + 1)] = this.port_arrys[i];
      } else {
        proxyobj['trade_type' + (i + 1)] = [];
      }
      hiernworexobj['new_ex' + (i + 1)] = this.hiernworex[i];
    } //portfolio

    var sub_id;
    var trd_val;
    var comapny_name;

    var score_name = {};
    var score_col = {};
    var val_low = {};
    var val_high = {};
    var rev = {};

    var scre_score_name = {};
    var scre_score_scehma = {};
    var scre_score_table = {};
    var scre_score_col = {};
    var scre_val_low = {};
    var scre_val_high = {};
    var scre_rev = {};

    var archdt = this.date_arch_model;

    for (var j = 0; j < this.scoreschema_asc.length; j++) {
      if (this.scoreschema_asc[j] !== undefined) {
        scre_score_name['scre_score_name' + (j + 1)] = this.scoretabnameid[j];
        scre_score_scehma['scre_score_schema' + (j + 1)] = this.scoreschema_asc[j];
        scre_score_table['scre_score_table' + (j + 1)] = this.scoretable_asc[j];
        scre_score_col['scre_score_col' + (j + 1)] = this.scorecolid_asc[j];
        scre_val_low['scre_val_low' + (j + 1)] = this.vallow_asc[j];
        scre_val_high['scre_val_high' + (j + 1)] = this.valhigh_asc[j];
        scre_rev['scre_rev' + (j + 1)] = this.reverse_asc[j];
      } else {
        scre_score_name['scre_score_name' + (j + 1)] = [];
        scre_score_scehma['score_schema' + (j + 1)] = [];
        scre_score_table['score_table' + (j + 1)] = [];
        scre_score_col['score_col' + (j + 1)] = [];
        scre_val_low['val_low' + (j + 1)] = [];
        scre_val_high['val_high' + (j + 1)] = [];
        scre_rev['rev' + (j + 1)] = [];
      }
    }

    var screcoll: any = this.scre_collectionvalid(
      this.scoretabnameid,
      this.scoreschema_asc,
      this.scoretable_asc,
      this.scorecolid_asc,
      this.vallow_asc,
      this.valhigh_asc,
      this.reverse_asc,
      'scores'
    );
    if (screcoll == true) {
      var low_highmand: any = this.low_highvalid(this.vallow_asc, this.valhigh_asc);
    }

    var screname_valid = 'false';
    var schema_valid = 'false';
    var table_valid = 'false';
    var screcol_valid = 'false';
    var vallow_valid = 'false';
    var valhigh_valid = 'false';
    var rev_valid = 'false';

    this.scoretabnameid = this.scoretabnameid.filter(function(v: any) {
      return v.trim() !== '';
    });

    this.scoreschema_asc = this.scoreschema_asc.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.scorecolid_asc = this.scorecolid_asc.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.vallow_asc = this.vallow_asc.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.valhigh_asc = this.valhigh_asc.filter(function(v: any) {
      return v.trim() !== '';
    });
    this.reverse_asc = this.reverse_asc.filter(function(v: any) {
      return v.trim() !== '';
    });

    if (
      this.scoretabnameid[0] != '' &&
      this.scoretabnameid[0] != null &&
      this.scoretabnameid[0] != undefined &&
      this.scoretabnameid.length > 0
    ) {
      screname_valid = 'true';
    } else {
      screname_valid = 'false';
      this.scretab_mand = false;
    }

    if (
      this.scoreschema_asc[0] != '' &&
      this.scoreschema_asc[0] != null &&
      this.scoreschema_asc[0] != undefined &&
      this.scoreschema_asc.length > 0
    ) {
      schema_valid = 'true';
    } else {
      schema_valid = 'false';
      this.scretab_mand = false;
    }

    if (
      this.scoretable_asc[0] != '' &&
      this.scoretable_asc[0] != null &&
      this.scoretable_asc[0] != undefined &&
      this.scoretable_asc.length > 0
    ) {
      table_valid = 'true';
    } else {
      table_valid = 'false';
      this.scretab_mand = false;
    }

    if (
      this.scorecolid_asc[0] != '' &&
      this.scorecolid_asc[0] != null &&
      this.scorecolid_asc[0] != undefined &&
      this.scorecolid_asc.length > 0
    ) {
      screcol_valid = 'true';
    } else {
      screcol_valid = 'false';
      this.scretab_mand = false;
    }
    if (
      this.vallow_asc[0] != '' &&
      this.vallow_asc[0] != null &&
      this.vallow_asc[0] != undefined &&
      this.vallow_asc.length > 0
    ) {
      vallow_valid = 'true';
    } else {
      vallow_valid = 'false';
      this.scretab_mand = false;
    }
    if (
      this.valhigh_asc[0] != '' &&
      this.valhigh_asc[0] != null &&
      this.valhigh_asc[0] != undefined &&
      this.valhigh_asc.length > 0
    ) {
      valhigh_valid = 'true';
    } else {
      valhigh_valid = 'false';
      this.scretab_mand = false;
    }
    if (
      this.reverse_asc[0] != '' &&
      this.reverse_asc[0] != null &&
      this.reverse_asc[0] != undefined &&
      this.reverse_asc.length > 0
    ) {
      rev_valid = 'true';
    } else {
      rev_valid = 'false';
      this.scretab_mand = false;
    }

    var hashpin = this.Hashcustmodel;
    if (hashpin != '' && hashpin) {
      hashpin = this.Hashcustmodel;
    } else {
      hashpin = '';
    }

    if (this.datasrc_check1 == true) {
      comapny_name = this.client_company_name;
      var dir = this.Dirid;
      var tbl_name = this.Tblid;
      var unique_cust = this.Uniqcustmodel;
      var appln_dec_col = this.dec_col_model;
      var appln_dt_col = this.appln_date_model;
      var dec_type = this.dec_model;
      var dt_format = this.date_format_model;
      var company_type = 'client table';
      sub_id = null;
      var booked = this.book_model;
      var apprvd_bookd = this.arrpvd_not_model;
      var declined = this.decline_model;
      var tdval = {};

      var perfm_win = null;

      var good_val = this.good_model;
      var inter_val = this.inter_model;
      var bad_val = this.bad_model;
      var loss_val = this.loss_model;

      localStorage.setItem('Directoryarray', JSON.stringify(this.DirName));
      localStorage.setItem('Decisioncolarray', JSON.stringify(this.custcol));
      localStorage.setItem('Decisionapprvd', JSON.stringify(this.dec_type));
      localStorage.setItem('Decisionapprv', JSON.stringify(this.dec_type_approvd)); //approvd
      localStorage.setItem('Decisionbookd', JSON.stringify(this.dec_type_booked)); //booked
      localStorage.setItem('Decisiondecl', JSON.stringify(this.dec_type_decl)); //declined
      localStorage.setItem('Hiervalsrc', JSON.stringify(this.dropdownList_trdval));
      localStorage.setItem('tblsrchdata', JSON.stringify(this.tblsrchdata));

      for (var i = 0; i < this.scorenameid.length; i++) {
        if (this.scorenameid[i] !== undefined) {
          score_name['score_name' + (i + 1)] = this.scorenameid[i];
          score_col['score_col' + (i + 1)] = this.scorecolid[i];
          val_low['val_low' + (i + 1)] = this.vallow[i];
          val_high['val_high' + (i + 1)] = this.valhigh[i];
          rev['rev' + (i + 1)] = this.reverse[i];
        } else {
          score_name['score_name' + (i + 1)] = [];
          score_col['score_col' + (i + 1)] = [];
          val_low['val_low' + (i + 1)] = [];
          val_high['val_high' + (i + 1)] = [];
          rev['rev' + (i + 1)] = [];
        }
      }

      for (var i = 0; i < this.Trdval.length; i++) {
        if (this.Trdval[i] !== undefined) {
          tdval['tdval' + (i + 1)] = this.Trdval[i];
        } else {
          tdval['tdval' + (i + 1)] = [];
        }
      }

      trd_val = tdval;

      if (this.StartDate) {
        this.FilteredStartdt = this.StartDate.year + '-' + this.StartDate.month + '-' + this.StartDate.day;
      }

      if (this.EndDate) {
        this.FilteredEnddt = this.EndDate.year + '-' + this.EndDate.month + '-' + this.EndDate.day;
      }
    } else if (this.datasrc_check2 == true) {
      var subid = {};
      var cmpydid = {};

      for (var i = 0; i < this.subarrys.length; i++) {
        if (this.subid[i] !== undefined) {
          subid['subid' + (i + 1)] = this.subid[i];
        } else {
          subid['subid' + (i + 1)] = null;
        }

        if (this.subid[i] !== undefined) {
          cmpydid['companyid' + (i + 1)] = this.ascend_company_name[i];
        } else {
          cmpydid['companyid' + (i + 1)] = null;
        }
      }

      var good_val = this.good_model_ascend;
      var inter_val = this.inter_model_ascend;
      var bad_val = this.bad_model_ascend;
      var loss_val = this.loss_model_ascend;

      localStorage.setItem('subscriberid', JSON.stringify(this.subid));
      localStorage.setItem('asc_companyname', JSON.stringify(this.ascend_company_name));

      sub_id = subid;
      comapny_name = cmpydid;
      var perf_win = this.perfwindmodel;
      trd_val = [];

      var company_type = 'ascend table';
      var dir = null;
      var tbl_name = null;
      var unique_cust = null;
      var appln_dec_col = null;
      var appln_dt_col = null;
      var dec_type = null;
      var dt_format = null;
      var booked = null;
      var apprvd_bookd = null;
      var declined = null;

      if (this.Ascend_StartDate) {
        this.FilteredStartdt =
          this.Ascend_StartDate.year + '-' + this.Ascend_StartDate.month + '-' + this.Ascend_StartDate.day;
      }

      if (this.Ascend_EndDate) {
        this.FilteredEnddt = this.Ascend_EndDate.year + '-' + this.Ascend_EndDate.month + '-' + this.Ascend_EndDate.day;
      }
    }

    let data: any = {
      company_type: company_type,
      company_name: comapny_name,
      directory: dir,
      tbl_name: tbl_name,
      uniquecust_col: unique_cust,
      appln_dec_col: appln_dec_col,
      appln_date_col: appln_dt_col,
      appln_dt_format: dt_format,
      booked: booked,
      apprvd_bookd: apprvd_bookd,
      performance_col: this.per_col_model,
      hash_pin: hashpin,

      scorename: score_name,
      scorecol: score_col,
      vallow: val_low,
      valhigh: val_high,
      reverse: rev,

      scre_score_name: scre_score_name,
      scre_score_scehma: scre_score_scehma,
      scre_score_table: scre_score_table,
      scre_score_col: scre_score_col,
      scre_val_low: scre_val_low,
      scre_val_high: scre_val_high,
      scre_rev: scre_rev,
      archivedt: archdt,

      declined: declined,
      predefined_scores: this.Scores,
      subcriber_id: sub_id,
      per_wind: perf_win,
      trade_col: this.trd_col_model,
      trade_type: proxyobj,
      trade_val: trd_val,
      public_rec: this.Publicrec,
      collection_rec: this.Collectionrec,
      validate: this.validat_model,
      new_trades: this.trades,
      mnth_after_appln: this.afterapplndate,
      perform_trade_data: this.tradedata,
      existing_worst_status: this.wrststatmodel,
      good: good_val,
      indeteminant: inter_val,
      bad: bad_val,
      loss: loss_val,
      start_dt: this.FilteredStartdt,
      end_dt: this.FilteredEnddt,
      per_snap_mnth: this.BaseMonth,
      per_snap_year: this.BaseYear,
      startdateorg: this.StartDate,
      endateorg: this.EndDate,
      startdateasc: this.Ascend_StartDate,
      endateorgasc: this.Ascend_EndDate
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    if (this.datasrc_check1 == true) {
      if (this.mandatory_req == false && this.client_company_name.trim()) {
        this.companyname_mand = true;
      } else {
        this.companyname_mand = false;
      }

      if (this.mandatory_req == false && this.Uniqcustmodel.trim()) {
        this.uniqcust_mand = true;
      } else {
        this.uniqcust_mand = false;
      }
      if (this.mandatory_req == false && this.Hashcustmodel.trim()) {
        this.hash_mand = true;
      } else {
        this.hash_mand = true;
      }

      if (this.mandatory_req == false && this.appln_date_model) {
        this.appldtcol_mand = true;
      } else {
        this.appldtcol_mand = false;
      }

      if (this.mandatory_req == false && this.date_format_model) {
        this.applndtfor_mand = true;
      } else {
        this.applndtfor_mand = false;
      }

      if (this.mandatory_req == false && this.dec_col_model) {
        this.applndeccol_mand = true;
      } else {
        this.applndeccol_mand = false;
      }

      if (this.mandatory_req == false && this.book_model.length > 0) {
        this.booked_mand = true;
      } else {
        this.booked_mand = false;
      }

      if (this.mandatory_req == false && this.arrpvd_not_model.length > 0) {
        this.apprvdnt_mand = true;
      } else {
        this.apprvdnt_mand = false;
      }

      if (this.mandatory_req == false && this.decline_model.length > 0) {
        this.decline_mand = true;
      } else {
        this.decline_mand = false;
      }
      if (
        data['trade_val']['tdval1'] != null ||
        data['trade_val']['tdval1'] != 'null' ||
        data['trade_val']['tdval1'] != ''
      ) {
        this.trdval_mand = true;
      } else {
        this.trdval_mand = false;
      }

      localStorage.setItem('Clientgood', JSON.stringify(this.good_defn));
      localStorage.setItem('Clientbad', JSON.stringify(this.bad_defn));
      localStorage.setItem('Clientinter', JSON.stringify(this.inter_defn));
      localStorage.setItem('Clientloss', JSON.stringify(this.loss_defn));
    } else {
      if (this.mandatory_req_type2 == false && this.ascend_company_name) {
        this.asc_cmpnyname_mand = true;
      } else {
        this.asc_cmpnyname_mand = false;
      }

      if (data['subcriber_id']['subid1'] != null && data['subcriber_id']['subid1'].trim()) {
        this.subid1_mand = true;
      } else {
        this.subid1_mand = false;
      }
    }

    if (this.good_model.length > 0) {
      this.good_mand = true;
    } else {
      this.good_mand = false;
    }

    if (this.bad_model.length > 0) {
      this.bad_mand = true;
    } else {
      this.bad_mand = false;
    }

    if (this.mandatory_req == false && this.Tblid.length > 0) {
      this.tblsrchmand = true;
    } else {
      this.tblsrchmand = false;
    }

    if (this.mandatory_req == false && this.Dirid) {
      this.dir_mand = true;
    } else {
      this.dir_mand = false;
    }

    var client_scre_arry: any = [];
    var scoretab_scre_arr: any = [];
    var finalrry: any;

    if (company_type == 'client table') {
      for (var i = 0; i < this.scorenameid.length; i++) {
        client_scre_arry.push({
          score_name: this.scorenameid[i],
          val_low: this.vallow[i],
          val_high: this.valhigh[i]
        });
      }

      for (var j = 0; j < this.scoreschema_asc.length; j++) {
        scoretab_scre_arr.push({
          score_name: this.scoretabnameid[j],
          val_low: this.vallow_asc[j],
          val_high: this.valhigh_asc[j]
        });
      }

      finalrry = scoretab_scre_arr.concat(client_scre_arry);
    } else {
      for (var j = 0; j < this.scoreschema_asc.length; j++) {
        scoretab_scre_arr.push({
          score_name: this.scoretabnameid[j],
          val_low: this.vallow_asc[j],
          val_high: this.valhigh_asc[j]
        });

        finalrry = scoretab_scre_arr;
        //console.log(finalrry);
      }

      var cmpn_subid: any = [];
      var cmpn_subid_final = [];

      for (var i = 0; i < this.subarrys.length; i++) {
        cmpn_subid.push({
          company_sub: this.ascend_company_name[i] + '(' + this.subid[i] + ')'
        });
      }

      for (var l = 0; l < cmpn_subid.length; l++) {
        cmpn_subid_final.push(cmpn_subid[l]['company_sub']);
        cmpn_subid_final.join();
      }

      localStorage.setItem('company_subid', JSON.stringify(cmpn_subid_final));
    }

    localStorage.setItem('screnameandval', JSON.stringify(finalrry));

    localStorage.setItem('retrivedata', JSON.stringify(data));
    localStorage.setItem('tradetype', JSON.stringify(this.port_arrys)); //portfolio
    //localStorage.setItem('tradetype', JSON.stringify(this.anArrays));

    localStorage.setItem('tradetypeval', JSON.stringify(this.Trdval));
    localStorage.setItem('scorename', JSON.stringify(this.scorenameid));
    localStorage.setItem('scorecolid', JSON.stringify(this.scorecolid));
    localStorage.setItem('vallow', JSON.stringify(this.vallow));
    localStorage.setItem('valhigh', JSON.stringify(this.valhigh));
    localStorage.setItem('reverse', JSON.stringify(this.reverse));

    localStorage.setItem('scre_name', JSON.stringify(this.scoretabnameid));
    localStorage.setItem('scre_schema', JSON.stringify(this.scoreschema_asc));
    localStorage.setItem('scre_table', JSON.stringify(this.scoretable_asc));
    localStorage.setItem('scre_column', JSON.stringify(this.scorecolid_asc));
    localStorage.setItem('scre_vallow', JSON.stringify(this.vallow_asc));
    localStorage.setItem('scre_valhigh', JSON.stringify(this.valhigh_asc));
    localStorage.setItem('scre_rev', JSON.stringify(this.reverse_asc));

    localStorage.setItem('scre_tbldata', JSON.stringify(this.scre_tbl));
    localStorage.setItem('scre_columndata', JSON.stringify(this.scre_col));

    if (
      (this.mandatory_req == false &&
        this.client_company_name.trim() &&
        this.Dirid &&
        this.Tblid.length > 0 &&
        this.Uniqcustmodel &&
        this.Hashcustmodel &&
        this.appln_date_model &&
        this.date_format_model &&
        this.book_model.length > 0 &&
        this.dec_col_model &&
        this.arrpvd_not_model.length > 0 &&
        this.decline_model.length > 0 &&
        schema_valid == 'true' &&
        table_valid == 'true' &&
        screcol_valid == 'true' &&
        vallow_valid == 'true' &&
        valhigh_valid == 'true' &&
        rev_valid == 'true') ||
      (this.mandatory_req_type2 == false &&
        schema_valid == 'true' &&
        table_valid == 'true' &&
        screcol_valid == 'true' &&
        vallow_valid == 'true' &&
        valhigh_valid == 'true' &&
        rev_valid == 'true')
    ) {
      if (low_highmand == true) {
        this.show_loader = true;
        this.scretab_mand = true;
        this.progressto90();
        this.homeservice.GenerateQuery(data).subscribe((apiresponse: any) => {
          // if (apiresponse.query == 'Success') {
          //   this.toastr.success('Data Saved Successfully !', 'Success');
          // } else {
          // }
          // if (apiresponse) {
          var portdata = [apiresponse.query];
          var subdata = [apiresponse.subscriber];
          console.log(subdata[0]);
          localStorage.setItem('portfolio', JSON.stringify(portdata[0][0]['portfolio_type']));
          localStorage.setItem('sub', JSON.stringify(subdata[0]));
          //localStorage.setItem('Chartdata', JSON.stringify(chartdata));
          this.router.navigate(['./chartview']); // change when response is dynamic
          //}
        });
      }
    } else {
      this.toastr.error('Please Fill out all mandatory fields!', 'Warning');
    }
  }
}
