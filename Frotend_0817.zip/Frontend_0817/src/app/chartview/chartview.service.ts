import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class ChartService {
  constructor(private httpClient: HttpClient) {}

  Getsummary_table(data: any) {
    return this.httpClient.post('summary_tab', { data: data }).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getscrecmpr_table(data: any) {
    return this.httpClient.post('screcmpr_tab', { data: data }).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getsummary_table_exprt(data: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('table_report', { data: data }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  GetBadrate_table_exprt(data: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('bad_rate_analysis_report', { data: data }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getscorechart_table_exprt(data: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('chart_report', { data: data }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getpcharts_table_exprt(data: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('p_chart_report', { data: data }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getscresummry_table_exprt(data: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('score_comparison_report', { data: data }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getparameters_table_exprt(data: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('parameter_report', { data: data }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Get_Pchart(data: any) {
    return this.httpClient.post('pchart', { data: data }).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  GetBadRate(data: any) {
    return this.httpClient.post('bad_rate', { data: data }).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Getscore_tab(data: any) {
    return this.httpClient.post('score_tab', { data: data }).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Exportall_table(data: any) {
    return this.httpClient.post('master_excel', { data: data }).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }

  Master_excel_report(data1: any) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };

    return this.httpClient.post('master_excel_report', { data: data1 }, httpOptions).pipe(
      map((body: any) => {
        if (body) {
          if (body) {
            return body;
          } else {
            return {};
          }
        } else {
          return {};
        }
      }),
      catchError(() => of([]))
    );
  }
}
