import { Component, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import HC_exporting from 'highcharts/modules/exporting';
import * as Highcharts from 'highcharts/highstock';
import HC_exportData from 'highcharts/modules/export-data';
import { MatRadioChange } from '@angular/material';
import { ChartService } from './chartview.service';
HC_exporting(Highcharts);
HC_exportData(Highcharts);
import { Router } from '@angular/router';

@Component({
  selector: 'app-chartview',
  templateUrl: './chartview.component.html',
  styleUrls: ['./chartview.component.scss']
})
export class ChartviewComponent implements OnInit {
  version: string = environment.version;
  portfoliotype: any = [
    'All',
    'Auto',
    'Mortgage',
    'Unsecured',
    'Secured',
    'Student Loans',
    'Credit Cards',
    'Home Equity',
    'Home Equity Credit Line'
  ];
  public score_type: any[] = [];
  public score_typebadrate: any[] = [];
  ScoreSettings = {};

  comparison_tbl: any = [];
  data: any = [];

  public trade_type: any[] = [];
  TradeSettings = {};

  book_type: any = ['Booked'];
  bookstatus: any = ['Booked', 'Approved Not Booked', 'Rejected'];

  score_model: any = [];
  show_column5: boolean = true;
  summary: any = [];
  summ_metric: any = [];
  summ_sample: any = [];
  summ_exclusion: any = [];
  summ_scorability: any = [];
  pcharts: any = [];
  pcharts_scres: any = [];
  pchart_table: any = [];
  pchart_total: any = [];
  badrate_scores: any = [];

  pchart_cumulative: any = {};
  pchart_tabl2: any = [];

  comparison: any = [];
  compar_tbl: any = [];

  score_perf: any = [];

  /*linechart1*/
  bad_ratetab: any = [];

  badratefinalarr: any = [];

  badcompfinalarr: any = [];

  badratescores: any = [];
  /*linechart1*/

  sum_trdtype: any = [];

  scrper_trdtype: any = [];

  scrcomp_trdtype: any = [];

  pchart_trdtype: any = [];

  badrat_trdtype: any = [];

  Summary_CompanyName: any;
  Screperfm_CompanyName: any;
  Badrate_CompanyName: any;
  Pchart_CompanyName: any;
  exprtall_trdtype: any;
  exprtall_CompanyName: any;

  cmpnyname: any = [];
  scores_value: any = [];
  Pchart_customrange: any = '20';
  custom_range: any = ['20', '10', '5', '4'];
  min_range: any = '100';
  max_range: any = '300';
  low_range: any;
  custm_disable: boolean = false;
  lwrrange_disable: boolean = true;

  //exprt variables
  summary_exprt_arry: any = [];

  scre_exprt_arry: any = [];

  Pchart_ScreName: any;

  Radio_pchart: any = '1';

  scre_cmp_col: any = [];
  scre_no: any;

  Screcmpr_CompanyName: any;
  usr_id: any;
  passwrd_id: any;
  subscriber_det: any = [];

  constructor(private router: Router, private chartservice: ChartService) {}

  ngOnInit() {
    this.usr_id = localStorage.getItem('user_name');
    // this.passwrd_id = localStorage.getItem('password');

    if (this.Radio_pchart == '1') {
      this.custm_disable = false;
      this.lwrrange_disable = true;

      this.Pchart_customrange = this.Pchart_customrange;
      this.min_range = null;
      this.max_range = null;
      this.low_range = null;
    } else {
      this.custm_disable = true;
      this.lwrrange_disable = false;
      this.Pchart_customrange = null;
      this.min_range = this.min_range;
      this.max_range = this.max_range;
      this.low_range = this.low_range;
    }

    var retrivedata: any = [];
    retrivedata = JSON.parse(localStorage.getItem('retrivedata') || '[]');

    var Clientscrename: any = [];
    Clientscrename = JSON.parse(localStorage.getItem('scorename') || '[]');

    var Scre_screname: any = [];
    Scre_screname = JSON.parse(localStorage.getItem('scre_name') || '[]');

    var client_scre_name: any = [];
    var scretab_scre_name: any = [];

    client_scre_name = Clientscrename;
    scretab_scre_name = Scre_screname;

    if (
      client_scre_name != '' ||
      client_scre_name != null ||
      client_scre_name != undefined ||
      client_scre_name.length > 0
    ) {
      scretab_scre_name = scretab_scre_name.concat(client_scre_name);
    } else {
      scretab_scre_name = scretab_scre_name;
    }
    this.scores_value = scretab_scre_name;
    this.score_type = scretab_scre_name;
    this.Pchart_ScreName = scretab_scre_name[0];

    for (var i = 0; i < scretab_scre_name.length; i++) {
      this.score_typebadrate.push({
        item_id_scores: scretab_scre_name[i],
        item_text_scores: scretab_scre_name[i]
      });
      this.badrate_scores.push({
        item_id_scores: scretab_scre_name[i],
        item_text_scores: scretab_scre_name[i]
      });
      this.score_model.push({
        item_id_scores: scretab_scre_name[i],
        item_text_scores: scretab_scre_name[i]
      });
    }

    this.GetParamtabledata(retrivedata);

    var portflio: any = [];
    portflio = JSON.parse(localStorage.getItem('tradetype') || '[]');

    var ascend_portflio: any = [];
    ascend_portflio = JSON.parse(localStorage.getItem('portfolio') || '[]');

    this.subscriber_det = JSON.parse(localStorage.getItem('sub') || '[]');

    //get company name
    if (retrivedata.company_type == 'client table') {
      this.cmpnyname.push(retrivedata.company_name);
      this.Summary_CompanyName = retrivedata.company_name;
      this.Screperfm_CompanyName = retrivedata.company_name;
      this.Badrate_CompanyName = retrivedata.company_name;
      this.Pchart_CompanyName = retrivedata.company_name;
      this.Screcmpr_CompanyName = retrivedata.company_name;
    } else {
      var cmpny_arry = Object.values(retrivedata.company_name);
      this.cmpnyname = cmpny_arry;

      this.Summary_CompanyName = cmpny_arry[0];
      this.Screperfm_CompanyName = cmpny_arry[0];
      this.Badrate_CompanyName = cmpny_arry[0];
      this.Pchart_CompanyName = cmpny_arry[0];
      this.Screcmpr_CompanyName = cmpny_arry[0];
    }

    if (retrivedata.company_type == 'client table') {
      if (
        portflio.length > 0 &&
        portflio[0] != 0 &&
        portflio[0] != '' &&
        portflio[0] != null &&
        portflio[0] != 'null'
      ) {
        for (var i = 0; i < portflio.length; i++) {
          this.trade_type.push({
            item_id: portflio[i],
            item_text: portflio[i]
          });
          this.sum_trdtype.push({
            item_id: portflio[i],
            item_text: portflio[i]
          });
          this.scrper_trdtype.push({
            item_id: portflio[i],
            item_text: portflio[i]
          });
          this.badrat_trdtype.push({
            item_id: portflio[i],
            item_text: portflio[i]
          });
          this.pchart_trdtype.push({
            item_id: portflio[i],
            item_text: portflio[i]
          });
          this.scrcomp_trdtype.push({
            item_id: portflio[i],
            item_text: portflio[i]
          });
        }
      } else {
        this.trade_type.push({
          item_id: 'Unknown',
          item_text: 'Unknown'
        });
        this.sum_trdtype.push({
          item_id: 'Unknown',
          item_text: 'Unknown'
        });
        this.scrper_trdtype.push({
          item_id: 'Unknown',
          item_text: 'Unknown'
        });
        this.badrat_trdtype.push({
          item_id: 'Unknown',
          item_text: 'Unknown'
        });
        this.pchart_trdtype.push({
          item_id: 'Unknown',
          item_text: 'Unknown'
        });
        this.scrcomp_trdtype.push({
          item_id: 'Unknown',
          item_text: 'Unknown'
        });
      }
    }

    if (retrivedata.company_type != 'client table') {
      if (ascend_portflio.length > 0) {
        for (var i = 0; i < ascend_portflio.length; i++) {
          this.trade_type.push({
            item_id: ascend_portflio[i],
            item_text: ascend_portflio[i]
          });
          this.sum_trdtype.push({
            item_id: ascend_portflio[i],
            item_text: ascend_portflio[i]
          });
          this.scrper_trdtype.push({
            item_id: ascend_portflio[i],
            item_text: ascend_portflio[i]
          });
          this.badrat_trdtype.push({
            item_id: ascend_portflio[i],
            item_text: ascend_portflio[i]
          });
          this.pchart_trdtype.push({
            item_id: ascend_portflio[i],
            item_text: ascend_portflio[i]
          });
          this.scrcomp_trdtype.push({
            item_id: ascend_portflio[i],
            item_text: ascend_portflio[i]
          });
        }
      }
    }

    this.Summary_Refresh();

    // this.trade_type = [];
    this.TradeSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.ScoreSettings = {
      singleSelection: false,
      idField: 'item_id_scores',
      textField: 'item_text_scores',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      enableCheckAll: false,
      allowSearchFilter: false
    };

    this.comparison = [];
    this.score_perf = [];

    this.bad_ratetab = [];

    this.pcharts_scres = [];

    this.badratescores = ['FICO 08', 'Vantage 4'];
  }

  backtohome() {
    this.router.navigate(['./home']);
  }

  onScoreDeSelect(event: any) {
    if (event.item_id_scores == 'Vantage 4') {
      this.show_column5 = false;
    }
  }

  onScoreSelect(event: any) {
    if (event.item_id_scores == 'Vantage 4') {
      this.show_column5 = true;
    }
  }
  good_bad(data: any) {
    // Create the chart

    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    (Highcharts as any).chart('container', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Good-Bad KS'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories']
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      plotOptions: {
        series: {
          pointWidth: 50
        }
      },

      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      series: yaxis_arr
    });
  }

  worst_capture_percent(data: any) {
    // Create the chart

    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    console.log(yaxis_arr);

    (Highcharts as any).chart('bad-capture', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Worst Score Capture(Number Of Bad for 10%)'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories']
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      series: yaxis_arr
    });
  }

  worst_capture_number(data: any) {
    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    // Create the chart
    (Highcharts as any).chart('worst-capture-number', {
      chart: {
        type: 'column'
      },

      title: {
        text: 'Worst Score Capture(10 % of Bad)'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories'],
        labels: {
          rotation: 0,
          style: {
            fontSize: '10px'
          }
        }
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          },
          formatter: function() {
            return this.value + '%';
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
      },
      series: yaxis_arr
    });
  }

  worst_capture_percent_20(data: any) {
    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    // Create the chart
    (Highcharts as any).chart('wrst-capture_twenty', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Worst Score Capture(Number Of Bad for 20%)'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories']
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      series: yaxis_arr
    });
  }

  worst_capture_number_20(data: any) {
    // Create the chart
    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    (Highcharts as any).chart('wrst-capture_twenty_num', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Worst Score Capture(20 % of Bad)'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories'],
        labels: {
          rotation: 0,
          style: {
            fontSize: '10px'
          }
        }
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          },
          formatter: function() {
            return this.value + '%';
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
      },
      series: yaxis_arr
    });
  }

  worst_capture_percent_30(data: any) {
    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    // Create the chart
    (Highcharts as any).chart('wrst-capture_thirty', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Worst Score Capture(Number Of Bad for 30%)'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories']
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      series: yaxis_arr
    });
  }

  worst_capture_number_30(data: any) {
    // Create the chart
    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    (Highcharts as any).chart('wrst-capture_thirty_num', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Worst Score Capture(30 % of Bad)'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories'],
        labels: {
          rotation: 0,
          style: {
            fontSize: '10px'
          }
        }
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          },
          formatter: function() {
            return this.value + '%';
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },
      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            pointWidth: 50,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
      },
      series: yaxis_arr
    });
  }
  Gini(data: any) {
    // Create the chart
    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];
    let yaxis_arr: any = [];

    for (var i = 0; i < data['series'].length; i++) {
      data['series'][i]['color'] = color[i];
    }

    for (var j = 0; j < data['series'].length; j++) {
      yaxis_arr.push({
        name: data['series'][j]['name'],
        color: color[j],
        data: [[data['series'][j]['name'], data['series'][j]['data'][0]]]
      });
    }

    (Highcharts as any).chart('gini', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Gini'
      },

      accessibility: {
        announceNewData: {
          enabled: true
        }
      },
      xAxis: {
        type: 'category',
        categories: data['categories']
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },
      legend: {
        enabled: true
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          pointWidth: 50,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 1000
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      },

      series: yaxis_arr
    });
  }

  total_counts(data: any) {
    Highcharts.setOptions({
      lang: {
        thousandsSep: ' '
      },
      colors: ['#e63888', '#0081a6']
    });
    Highcharts.chart('total-counts', {
      chart: {
        type: 'column'
        // zoomType: 'y',
        //backgroundColor:"#FBFAE4"
      },
      title: {
        text: 'Total Vs BadCounts'
      },

      xAxis: {
        categories: data['categories'],
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: ''
        }
      },

      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      series: data['series']
    });
  }

  linechart(scores: any) {
    var color = ['#e63888', '#0081a6', '#6d2077', '#af1685'];
    var badrate = scores['badrate_charts'][0]['bad_distribution'];

    for (var i = 0; i < badrate[0]['y-axis'][0][this.book_type].length; i++) {
      badrate[0]['y-axis'][0][this.book_type][i]['color'] = color[i];
    }
    var x_axis: any = [];
    x_axis = badrate[0]['x-axis'];

    var dibadarr = [];
    dibadarr = badrate[0]['y-axis'][0][this.book_type];

    var comparr = [];
    comparr = this.badrate_scores;

    this.badratefinalarr = [];

    for (var i = 0; i < comparr.length; i++) {
      for (var j = 0; j < dibadarr.length; j++) {
        if (dibadarr[j]['name'] == comparr[i]['item_id_scores']) {
          this.badratefinalarr.push({
            name: dibadarr[j]['name'],
            data: dibadarr[j]['data'],
            color: color[j]
          });
        }
      }
    }

    console.log(this.badratefinalarr);
    Highcharts.chart('line-conatiner', {
      chart: {
        type: 'column'
      },

      title: {
        text: 'Distribution of Bad'
      },

      subtitle: {
        text: ''
      },

      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {},
          formatter: function() {
            return this.value + '%';
          }
        }
      },

      xAxis: {
        type: 'category',
        categories: x_axis,
        maxPadding: 0.6,
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },

      legend: {
        layout: 'horizontal',
        align: 'center',
        verticalAlign: 'bottom'
      },
      credits: {
        enabled: false
      },

      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },

      series: this.badratefinalarr,

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      }
    });
  }

  linechart2(scores: any) {
    var color = ['#e63888', '#0081a6', '#6d2077', '#af1685'];
    var badrate = scores['badrate_charts'][0]['bad_intervalrate'];

    for (var i = 0; i < badrate[0]['y-axis'][0][this.book_type].length; i++) {
      badrate[0]['y-axis'][0][this.book_type][i]['color'] = color[i];
    }

    var dibadcomp = [];
    dibadcomp = badrate[0]['y-axis'][0][this.book_type];

    var comparr = [];
    comparr = this.badrate_scores;
    // console.log(comparr);

    this.badcompfinalarr = [];

    for (var i = 0; i < comparr.length; i++) {
      for (var j = 0; j < dibadcomp.length; j++) {
        if (dibadcomp[j]['name'] == comparr[i]['item_id_scores']) {
          this.badcompfinalarr.push({
            name: dibadcomp[j]['name'],
            data: dibadcomp[j]['data'],
            color: color[j]
          });
        }
      }
    }

    Highcharts.chart('line-conatiner2', {
      chart: {
        type: 'column'
      },

      title: {
        text: 'Bad Rate'
      },

      subtitle: {
        text: ''
      },

      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {},
          formatter: function() {
            return this.value + '%';
          }
        }
      },

      xAxis: {
        type: 'category',
        categories: badrate[0]['x-axis'],
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },

      legend: {
        layout: 'horizontal',
        align: 'center',
        verticalAlign: 'bottom'
      },
      credits: {
        enabled: false
      },

      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },

      series: this.badcompfinalarr,

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      }
    });
  }

  cumbadrate(scores: any) {
    var color = ['#e63888', '#0081a6', '#6d2077', '#af1685'];
    var badrate = scores['badrate_charts'][0]['bad_cumulative'];

    for (var i = 0; i < badrate[0]['y-axis'][0][this.book_type].length; i++) {
      badrate[0]['y-axis'][0][this.book_type][i]['color'] = color[i];
    }

    var dibadcomp = [];
    dibadcomp = badrate[0]['y-axis'][0][this.book_type];

    var comparr = [];
    comparr = this.badrate_scores;
    // console.log(comparr);

    this.badcompfinalarr = [];

    for (var i = 0; i < comparr.length; i++) {
      for (var j = 0; j < dibadcomp.length; j++) {
        if (dibadcomp[j]['name'] == comparr[i]['item_id_scores']) {
          this.badcompfinalarr.push({
            name: dibadcomp[j]['name'],
            data: dibadcomp[j]['data'],
            color: color[j]
          });
        }
      }
    }

    Highcharts.chart('cumulative', {
      chart: {
        type: 'column'
      },

      title: {
        text: 'Cumulative Bad Rate'
      },

      subtitle: {
        text: ''
      },

      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {},
          formatter: function() {
            return this.value + '%';
          }
        }
      },

      xAxis: {
        type: 'category',
        categories: badrate[0]['x-axis'],
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '12px',
            fontFamily: 'Arial'
          }
        }
      },

      legend: {
        layout: 'horizontal',
        align: 'center',
        verticalAlign: 'bottom'
      },
      credits: {
        enabled: false
      },

      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },

      series: this.badcompfinalarr,

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      }
    });
  }

  barchart3(data: any) {
    console.log(data);
    var badrate = data['badrate_charts'][0]['badcapture'][0];
    Highcharts.setOptions({
      lang: {
        thousandsSep: ' '
      }
    });

    var color = [
      '#e63888',
      '#0081a6',
      '#6d2077',
      '#af1685',
      '#F790C6',
      '#79C8DE',
      '#C186C9',
      '#8DABD4',
      '#FFD8F0',
      '#D0EFF8',
      '#F0DEF2',
      '#D6E3F4',
      '#009f4d',
      '#b7bf10',
      '#00b2a9',
      '#ff8f1c',
      '#ffd146'
    ];
    for (var i = 0; i < badrate['y-axis'].length; i++) {
      badrate['y-axis'][i]['color'] = color[i];
    }

    Highcharts.chart('line-conatiner3', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Bad capture'
      },

      xAxis: {
        categories: badrate['x-axis'],
        crosshair: true
      },
      yAxis: {
        title: {
          text: ''
        },
        labels: {
          rotation: 0,
          style: {},
          formatter: function() {
            return this.value + '%';
          }
        }
      },

      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: false,
            format: '{point.y:.1f}%'
          }
        }
      },
      series: badrate['y-axis']
    });
  }

  stackedchart(data: any) {
    var color = ['#e63888', '#0081a6'];

    for (var i = 0; i < this.bad_ratetab[0]['chart11'][0]['y-axis'].length; i++) {
      this.bad_ratetab[0]['chart11'][0]['y-axis'][i]['color'] = color[i];
    }

    Highcharts.chart('stack-container', {
      chart: {
        type: 'column'
        // width: 800
      },

      title: {
        text: 'Population Distributions'
      },
      xAxis: {
        categories: this.bad_ratetab[0]['chart11'][0]['x-axis'],
        title: {
          text: 'Vantage 4'
        },
        labels: {
          rotation: 0,
          style: {
            fontSize: '10px'
          }
        }
      },

      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        }
      },
      legend: {
        layout: 'vertical'
      },
      credits: {
        enabled: false
      },

      exporting: {
        enabled: true,

        buttons: {
          contextButton: {
            menuItems: ['downloadJPEG', 'downloadPDF', 'downloadCSV']
          }
        }
      },

      series: this.bad_ratetab[0]['chart11'][0]['y-axis']
    });
  }

  Summary_Refresh() {
    var data: any = {
      tradetype: this.sum_trdtype,
      company_name: this.Summary_CompanyName
    };
    this.Getsummarytable(data);
  }

  Score_Refresh() {
    var data: any = {
      tradetype: this.sum_trdtype,
      company_name: this.Summary_CompanyName
    };
    this.Getscorecharts(data);
  }

  BadRate_Refresh() {
    var data: any = {
      tradetype: this.sum_trdtype,
      company_name: this.Summary_CompanyName,
      scores: this.badrate_scores,
      booking_type: this.book_type
    };

    this.Getbadrate_analysis(data);
  }

  Pchart_Refresh() {
    var portarry: any = [];

    var data: any = {
      tradetype: this.sum_trdtype,
      company_name: this.Summary_CompanyName,
      scores: this.Pchart_ScreName,
      custom_range: this.Pchart_customrange,
      min_range: this.min_range,
      max_range: this.max_range,
      low_range: this.low_range
      // user_id: this.usr_id,
      // password: this.passwrd_id
    };

    this.GetPchart(data);
  }

  Pcharts_value() {
    var GetrangeData = JSON.parse(localStorage.getItem('screnameandval') || '[]');
    let scorname = this.Pchart_ScreName;

    for (var i = 0; i < GetrangeData.length; i++) {
      if (scorname == GetrangeData[i]['score_name']) {
        this.min_range = GetrangeData[i]['val_low'];
        this.max_range = GetrangeData[i]['val_high'];
        console.log(GetrangeData[i]['val_low']);
        console.log(GetrangeData[i]['val_high']);
      }
    }
  }

  Pchart_exprt: any = [];
  indeterminant_percentage_pchart: any = [];
  indeterminant_percentage_cuml: any = [];

  GetPchart(data: any) {
    this.chartservice.Get_Pchart(data).subscribe((apiresponse: any) => {
      this.Pchart_exprt = [];
      this.pchart_table = [];
      this.pchart_tabl2 = [];
      this.pchart_total = [];
      if (apiresponse) {
        console.log(apiresponse['p_charts']);
        var pchart_tbl1 = apiresponse['p_charts'];

        this.Pchart_exprt = apiresponse;

        let sno: any = [];

        for (var i = 0; i < pchart_tbl1[0]['score_range'].length; i++) {
          sno.push(i + 1);
        }

        this.Pchart_exprt['cumulative'][0]['sno'] = sno;
        this.Pchart_exprt['p_charts'][0]['sno'] = sno;

        console.log(this.Pchart_exprt);

        this.indeterminant_percentage_pchart = pchart_tbl1[0]['indeterminant_percent'];

        //PCHARTS
        for (var i = 0; i < pchart_tbl1[0]['score_range'].length; i++) {
          this.pchart_table.push({
            twentile: i + 1,
            score_range: pchart_tbl1[0]['score_range'][i],
            total: pchart_tbl1[0]['total'][i],
            reject: pchart_tbl1[0]['reject'][i],
            reject_percent: pchart_tbl1[0]['reject_percent'][i],
            approved: pchart_tbl1[0]['approved'][i],
            approved_percent: pchart_tbl1[0]['approved_percent'][i],
            approved_not_booked: pchart_tbl1[0]['approved_not_booked'][i],
            approved_not_booked_percent: pchart_tbl1[0]['approved_not_booked_percent'][i],
            booked: pchart_tbl1[0]['booked'][i],
            booked_percent: pchart_tbl1[0]['booked_percent'][i],
            good: pchart_tbl1[0]['good'][i],
            good_percent: pchart_tbl1[0]['booked_percent'][i],
            indeterminant: pchart_tbl1[0]['indeterminant'][i],
            indeterminant_percent: pchart_tbl1[0]['indeterminant_percent'][i],
            bad: pchart_tbl1[0]['bad'][i],
            bad_percent: pchart_tbl1[0]['bad_percent'][i],
            loss: pchart_tbl1[0]['loss'][i],
            loss_percent: pchart_tbl1[0]['loss_percent'][i]
          });
        }

        for (var i = 0; i < pchart_tbl1[0]['finaltotal'].length; i++) {
          this.pchart_total.push({
            sum: pchart_tbl1[0]['finaltotal'][i]
          });
        }

        //PCHARTS

        var pchart_cumulative = apiresponse['cumulative'];

        this.indeterminant_percentage_cuml = pchart_cumulative[0]['indeterminant_percent'];

        //pchart pchart_cumulative
        for (var i = 0; i < pchart_cumulative[0]['score_range'].length; i++) {
          this.pchart_tabl2.push({
            twentile: i + 1,
            score_range: pchart_cumulative[0]['score_range'][i],
            total: pchart_cumulative[0]['total'][i],
            reject: pchart_cumulative[0]['reject'][i],
            reject_percent: pchart_cumulative[0]['reject_percent'][i],
            approved: pchart_cumulative[0]['approved'][i],
            approved_percent: pchart_cumulative[0]['approved_percent'][i],
            approved_not_booked: pchart_cumulative[0]['approved_not_booked'][i],
            approved_not_booked_percent: pchart_cumulative[0]['approved_not_booked_percent'][i],
            booked: pchart_cumulative[0]['booked'][i],
            booked_percent: pchart_cumulative[0]['booked_percent'][i],
            good: pchart_cumulative[0]['good'][i],
            good_percent: pchart_cumulative[0]['good_percent'][i],
            indeterminant: pchart_cumulative[0]['indeterminant'][i],
            indeterminant_percent: pchart_cumulative[0]['indeterminant_percent'][i],
            bad: pchart_cumulative[0]['bad'][i],
            bad_percent: pchart_cumulative[0]['bad_percent'][i],
            loss: pchart_cumulative[0]['loss'][i],
            loss_percent: pchart_cumulative[0]['loss_percent'][i]
          });
        }

        //pchart pchart_cumulative
      }
    });
  }

  GetPchart_export() {
    var data: any = [];
    var porttype: any = [];

    for (var i = 0; i < this.sum_trdtype.length; i++) {
      porttype.push(this.sum_trdtype[i]['item_id']);
    }
    var cmpnyarry: any = [];
    var scre_arry: any = [];
    cmpnyarry.push(this.Summary_CompanyName);
    scre_arry.push(this.Pchart_ScreName);

    var min_range: any = [];
    min_range.push(this.min_range);

    var fixed_range: any = [];
    fixed_range.push(this.Pchart_customrange);

    var max_range: any = [];
    max_range.push(this.max_range);

    var low_range: any = [];
    low_range.push(this.low_range);

    var archdt: any = [];
    var start_dt: any = [];
    var end_dt: any = [];
    var good: any = [];
    var bad: any = [];
    var ind: any = [];
    var loss: any = [];
    var appln_dt: any = [];

    if (this.param_startdt && this.param_startdt != '' && this.param_startdt != undefined) {
      start_dt.push(this.param_startdt);
    } else {
      start_dt.push('-');
    }

    if (this.param_enddt && this.param_enddt != '' && this.param_enddt != undefined) {
      end_dt.push(this.param_enddt);
    } else {
      end_dt.push('-');
    }

    if (this.param_good[0] != '' && this.param_good[0] != undefined && this.param_good.length > 0) {
      good.push(this.param_good.join());
    } else {
      good.push('-');
    }

    if (this.param_bad[0] != '' && this.param_bad[0] != undefined && this.param_bad.length > 0) {
      bad.push(this.param_bad.join());
    } else {
      bad.push('-');
    }

    if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
      ind.push(this.param_inter.join());
    } else {
      ind.push('-');
    }

    if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
      loss.push(this.param_loss.join());
    } else {
      loss.push('-');
    }

    if (this.param_archdt != '' && this.param_archdt != undefined) {
      archdt.push(this.param_archdt);
    } else {
      archdt.push('-');
    }

    if (this.param_appldtcol && this.param_appldtcol != '' && this.param_appldtcol != undefined) {
      appln_dt.push(this.param_appldtcol);
    } else {
      appln_dt.push('-');
    }

    var subid: any = [];

    for (var i = 0; i < this.subscriber_det.length; i++) {
      subid.push({ count: [this.subscriber_det[i]['count']], name: [this.subscriber_det[i]['name']] });
    }

    if (this.lwrrange_disable == true) {
      data = {
        Pchart_table: this.Pchart_exprt,
        company_name: cmpnyarry,
        portfoliotype: porttype,
        score_name: scre_arry,
        range_type: 'Fixed range',
        range: fixed_range,
        start_dt: start_dt,
        end_dt: end_dt,
        good: good,
        bad: bad,
        ind: ind,
        loss: loss,
        archdt: archdt,
        appln_dt: appln_dt,
        subscriber: subid
      };
    } else {
      data = {
        Pchart_table: this.Pchart_exprt,
        company_name: cmpnyarry,
        portfoliotype: porttype,
        score_name: scre_arry,
        range_type: 'Custom range',
        min_range: min_range,
        low_range: low_range,
        max_range: max_range,
        start_dt: start_dt,
        end_dt: end_dt,
        good: good,
        bad: bad,
        ind: ind,
        loss: loss,
        archdt: archdt,
        appln_dt: appln_dt,
        subscriber: subid
      };
    }

    var date = this.getdatetime();

    this.chartservice.Getpcharts_table_exprt(data).subscribe((apiresponse: any) => {
      const blob = new Blob([apiresponse], {
        type: 'application/vnd.ms.excel'
      });

      var downloadURL = window.URL.createObjectURL(apiresponse);
      var link = document.createElement('a');
      link.href = downloadURL;
      var filename: any = 'Pcharts' + date;
      link.download = filename + '.xlsx';
      link.click();
      if (apiresponse) {
      }
    });
  }

  Exportall_export() {
    var data: any = {
      tradetype: this.exprtall_trdtype,
      company_name: this.exprtall_CompanyName
    };
    var archdt: any = [];
    var start_dt: any = [];
    var end_dt: any = [];
    var good: any = [];
    var bad: any = [];
    var ind: any = [];
    var loss: any = [];
    var appln_dt: any = [];

    if (this.param_startdt && this.param_startdt != '' && this.param_startdt != undefined) {
      start_dt.push(this.param_startdt);
    } else {
      start_dt.push('-');
    }

    if (this.param_enddt && this.param_enddt != '' && this.param_enddt != undefined) {
      end_dt.push(this.param_enddt);
    } else {
      end_dt.push('-');
    }

    if (this.param_good[0] != '' && this.param_good[0] != undefined && this.param_good.length > 0) {
      good.push(this.param_good.join());
    } else {
      good.push('-');
    }

    if (this.param_bad[0] != '' && this.param_bad[0] != undefined && this.param_bad.length > 0) {
      bad.push(this.param_bad.join());
    } else {
      bad.push('-');
    }

    if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
      ind.push(this.param_inter.join());
    } else {
      ind.push('-');
    }

    if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
      loss.push(this.param_loss.join());
    } else {
      loss.push('-');
    }

    if (this.param_archdt != '' && this.param_archdt != undefined) {
      archdt.push(this.param_archdt);
    } else {
      archdt.push('-');
    }

    if (this.param_appldtcol && this.param_appldtcol != '' && this.param_appldtcol != undefined) {
      appln_dt.push(this.param_appldtcol);
    } else {
      appln_dt.push('-');
    }

    var subid: any = [];

    for (var i = 0; i < this.subscriber_det.length; i++) {
      subid.push({ count: [this.subscriber_det[i]['count']], name: [this.subscriber_det[i]['name']] });
    }

    this.chartservice.Exportall_table(data).subscribe((apiresponse: any) => {
      if (apiresponse) {
        var data1: any = {};
        data1 = apiresponse.data[0];
        data1.parameter = this.Getparam_export_master();
        data1.start_dt = start_dt;
        data1.end_dt = end_dt;
        data1.good = good;
        data1.bad = bad;
        data1.ind = ind;
        data1.loss = loss;
        data1.archdt = archdt;
        data1.appln_dt = appln_dt;
        data1.subscriber = subid;

        var date = this.getdatetime();

        this.chartservice.Master_excel_report(data1).subscribe((excel_response: any) => {
          if (excel_response) {
            const blob = new Blob([excel_response], {
              type: 'application/vnd.ms.excel'
            });

            var downloadURL = window.URL.createObjectURL(excel_response);
            var link = document.createElement('a');
            link.href = downloadURL;
            var filename: any = 'Masterexcel' + date;
            link.download = filename + '.xlsx';
            link.click();
          }
        });
      }
    });
  }

  summary_table3header: any = [];

  Getsummarytable(data: any) {
    this.summ_metric = [];
    this.summ_sample = [];
    this.summ_exclusion = [];
    this.summ_scorability = [];
    this.summary_table3header = [];
    this.chartservice.Getsummary_table(data).subscribe((apiresponse: any) => {
      if (apiresponse) {
        //Export array
        this.summary_exprt_arry = apiresponse['summary_charts'][0];

        for (var i = 0; i < apiresponse['summary_charts'][0]['table1'][0]['scores'].length; i++) {
          this.summ_metric.push({
            scores: apiresponse['summary_charts'][0]['table1'][0]['scores'][i],
            KS: apiresponse['summary_charts'][0]['table1'][0]['KS'][i],
            gini: apiresponse['summary_charts'][0]['table1'][0]['gini'][i],
            good_badmrd: apiresponse['summary_charts'][0]['table1'][0]['good_badmrd'][i],
            tenper_bad_cap: apiresponse['summary_charts'][0]['table1'][0]['10% bad capture'][i],
            tennum_bad_cap: apiresponse['summary_charts'][0]['table1'][0]['10% bad #'][i],
            tweper_bad_cap: apiresponse['summary_charts'][0]['table1'][0]['20% bad capture'][i],
            twenum_bad_cap: apiresponse['summary_charts'][0]['table1'][0]['20% bad #'][i],
            thirper_bad_cap: apiresponse['summary_charts'][0]['table1'][0]['30% bad capture'][i],
            thirnum_bad_cap: apiresponse['summary_charts'][0]['table1'][0]['30% bad #'][i],
            reject_accept: apiresponse['summary_charts'][0]['table1'][0]['RejectAccept'][i]
          });
        }

        //table2
        for (var i = 0; i < apiresponse['summary_charts'][0]['table2'][0]['scores'].length; i++) {
          this.summ_sample.push({
            scores: apiresponse['summary_charts'][0]['table2'][0]['scores'][i],
            Total: apiresponse['summary_charts'][0]['table2'][0]['Total'][i],
            Decline: apiresponse['summary_charts'][0]['table2'][0]['Decline'][i],
            Approved_Not_Booked: apiresponse['summary_charts'][0]['table2'][0]['Approved_Not_Booked'][i],
            Good: apiresponse['summary_charts'][0]['table2'][0]['Good'][i],
            Indeterminant: apiresponse['summary_charts'][0]['table2'][0]['Indeterminant'][i],
            Total_Bad: apiresponse['summary_charts'][0]['table2'][0]['Total_Bad'][i],
            Loss: apiresponse['summary_charts'][0]['table2'][0]['Loss'][i],
            Total_Booked: apiresponse['summary_charts'][0]['table2'][0]['Total_Booked'][i],
            Badrate: apiresponse['summary_charts'][0]['table2'][0]['Badrate'][i],
            Lossrate: apiresponse['summary_charts'][0]['table2'][0]['Lossrate'][i],
            perbadloss: apiresponse['summary_charts'][0]['table2'][0]['% bad loss'][i],
            Approved: apiresponse['summary_charts'][0]['table2'][0]['Approved'][i],
            Approved_rate: apiresponse['summary_charts'][0]['table2'][0]['Approved_rate'][i]
          });
        }
        var sumry_table3 = apiresponse['summary_charts'][0]['table3'][0];

        for (var i = 0; i < apiresponse['summary_charts'][0]['table3'][0]['input_params'].length; i++) {
          this.summary_table3header.push(apiresponse['summary_charts'][0]['table3'][0]['input_params'][i]);
        }

        //table3
        apiresponse['summary_charts'][0]['table3'][0]['input_params'];
        for (var i = 0; i < apiresponse['summary_charts'][0]['table3'][0]['input_params'].length; i++) {
          var tbl3data = Object.keys(sumry_table3);

          if (tbl3data[i] != 'input_params') {
            this.summ_exclusion.push(apiresponse['summary_charts'][0]['table3'][0][tbl3data[i]]);
          }
        }

        console.log(this.summ_exclusion);
        for (var i = 0; i < apiresponse['summary_charts'][0]['scorable'][0]['score_names'].length; i++) {
          this.summ_scorability.push({
            score_names: apiresponse['summary_charts'][0]['scorable'][0]['score_names'][i],
            Exclusions_count: apiresponse['summary_charts'][0]['scorable'][0]['Exclusions_count'][i],
            Valid_count: apiresponse['summary_charts'][0]['scorable'][0]['Valid_count'][i],
            Excl_percent: apiresponse['summary_charts'][0]['scorable'][0]['Excl_percent'][i],
            Valid_percent: apiresponse['summary_charts'][0]['scorable'][0]['Valid_percent'][i]
          });
        }
      }
    });
  }

  badrate_exprt_arry: any = [];

  Getbadrate_analysis(data: any) {
    this.chartservice.GetBadRate(data).subscribe((apiresponse: any) => {
      if (apiresponse) {
        console.log(apiresponse);
        this.linechart(apiresponse);
        this.linechart2(apiresponse);
        this.barchart3(apiresponse);
        this.cumbadrate(apiresponse);
        this.badrate_exprt_arry = apiresponse;
      }
    });
  }

  Getbadratechrt_export() {
    var cmpny_arry: any = [];
    cmpny_arry.push(this.Summary_CompanyName);
    var porttype: any = [];

    var scres: any = [];

    var bktype: any = [];

    var archdt: any = [];
    var start_dt: any = [];
    var end_dt: any = [];
    var good: any = [];
    var bad: any = [];
    var ind: any = [];
    var loss: any = [];
    var appln_dt: any = [];

    if (this.param_startdt && this.param_startdt != '' && this.param_startdt != undefined) {
      start_dt.push(this.param_startdt);
    } else {
      start_dt.push('-');
    }

    if (this.param_enddt && this.param_enddt != '' && this.param_enddt != undefined) {
      end_dt.push(this.param_enddt);
    } else {
      end_dt.push('-');
    }

    if (this.param_good[0] != '' && this.param_good[0] != undefined && this.param_good.length > 0) {
      good.push(this.param_good.join());
    } else {
      good.push('-');
    }

    if (this.param_bad[0] != '' && this.param_bad[0] != undefined && this.param_bad.length > 0) {
      bad.push(this.param_bad.join());
    } else {
      bad.push('-');
    }

    if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
      ind.push(this.param_inter.join());
    } else {
      ind.push('-');
    }

    if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
      loss.push(this.param_loss.join());
    } else {
      loss.push('-');
    }

    if (this.param_archdt != '' && this.param_archdt != undefined) {
      archdt.push(this.param_archdt);
    } else {
      archdt.push('-');
    }

    if (this.param_appldtcol && this.param_appldtcol != '' && this.param_appldtcol != undefined) {
      appln_dt.push(this.param_appldtcol);
    } else {
      appln_dt.push('-');
    }
    // bktype.push(this.book_type)

    for (var i = 0; i < this.sum_trdtype.length; i++) {
      porttype.push(this.sum_trdtype[i]['item_id']);
    }

    for (var i = 0; i < this.badrate_scores.length; i++) {
      scres.push(this.badrate_scores[i]['item_id_scores']);
    }

    var subid: any = [];

    for (var i = 0; i < this.subscriber_det.length; i++) {
      subid.push({ count: [this.subscriber_det[i]['count']], name: [this.subscriber_det[i]['name']] });
    }
    var data: any = {
      tab5: this.badrate_exprt_arry,
      company_name: cmpny_arry,
      porttype: porttype,
      scores: scres,
      booking_type: this.book_type,
      start_dt: start_dt,
      end_dt: end_dt,
      good: good,
      bad: bad,
      ind: ind,
      loss: loss,
      archdt: archdt,
      appln_dt: appln_dt,
      subscriber: subid
    };
    var date = this.getdatetime();

    this.chartservice.GetBadrate_table_exprt(data).subscribe((apiresponse: any) => {
      const blob = new Blob([apiresponse], {
        type: 'application/vnd.ms.excel'
      });

      var downloadURL = window.URL.createObjectURL(apiresponse);
      var link = document.createElement('a');
      link.href = downloadURL;
      var filename: any = 'badrate' + date;
      link.download = filename + '.xlsx';
      link.click();

      if (apiresponse) {
      }
    });
  }

  getdatetime() {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ':' + today.getMinutes();
    var dateTime = date + '__' + time;

    return dateTime;
  }

  Getsummarytable_export() {
    var cmpny_arry: any = [];
    cmpny_arry.push(this.Summary_CompanyName);
    var porttype: any = [];
    var archdt: any = [];
    var start_dt: any = [];
    var end_dt: any = [];
    var good: any = [];
    var bad: any = [];
    var ind: any = [];
    var loss: any = [];
    var appln_dt: any = [];

    console.log(this.param_appldtcol);

    for (var i = 0; i < this.sum_trdtype.length; i++) {
      porttype.push(this.sum_trdtype[i]['item_id']);
    }

    var date = this.getdatetime();

    if (this.param_startdt && this.param_startdt != '' && this.param_startdt != undefined) {
      start_dt.push(this.param_startdt);
    } else {
      start_dt.push('-');
    }

    if (this.param_enddt && this.param_enddt != '' && this.param_enddt != undefined) {
      end_dt.push(this.param_enddt);
    } else {
      end_dt.push('-');
    }

    if (this.param_good[0] != '' && this.param_good[0] != undefined && this.param_good.length > 0) {
      good.push(this.param_good.join());
    } else {
      good.push('-');
    }

    if (this.param_bad[0] != '' && this.param_bad[0] != undefined && this.param_bad.length > 0) {
      bad.push(this.param_bad.join());
    } else {
      bad.push('-');
    }

    if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
      ind.push(this.param_inter.join());
    } else {
      ind.push('-');
    }

    if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
      loss.push(this.param_loss.join());
    } else {
      loss.push('-');
    }

    if (this.param_archdt != '' && this.param_archdt != undefined) {
      archdt.push(this.param_archdt);
    } else {
      archdt.push('-');
    }

    if (this.param_appldtcol && this.param_appldtcol != '' && this.param_appldtcol != undefined) {
      appln_dt.push(this.param_appldtcol);
    } else {
      appln_dt.push('-');
    }
    var subid: any = [];

    for (var i = 0; i < this.subscriber_det.length; i++) {
      subid.push({ count: [this.subscriber_det[i]['count']], name: [this.subscriber_det[i]['name']] });
    }

    console.log(subid);

    var data: any = {
      tab1: this.summary_exprt_arry,
      company_name: cmpny_arry,
      porttype: porttype,
      start_dt: start_dt,
      end_dt: end_dt,
      good: good,
      bad: bad,
      ind: ind,
      loss: loss,
      archdt: archdt,
      appln_dt: appln_dt,
      subscriber: subid
    };
    this.chartservice.Getsummary_table_exprt(data).subscribe((apiresponse: any) => {
      const blob = new Blob([apiresponse], {
        type: 'application/vnd.ms.excel'
      });

      var downloadURL = window.URL.createObjectURL(apiresponse);
      var link = document.createElement('a');
      link.href = downloadURL;
      var filename: any = 'summary_' + date;
      link.download = filename + '.xlsx';
      link.click();

      if (apiresponse) {
      }
    });
  }

  Getscoreperformance_export() {
    var cmpny_arry: any = [];
    cmpny_arry.push(this.Summary_CompanyName);
    var porttype: any = [];
    var archdt: any = [];
    var start_dt: any = [];
    var end_dt: any = [];
    var good: any = [];
    var bad: any = [];
    var ind: any = [];
    var loss: any = [];
    var appln_dt: any = [];

    console.log(this.sum_trdtype);

    for (var i = 0; i < this.sum_trdtype.length; i++) {
      porttype.push(this.sum_trdtype[i]['item_id']);
    }

    var date = this.getdatetime();

    if (this.param_startdt && this.param_startdt != '' && this.param_startdt != undefined) {
      start_dt.push(this.param_startdt);
    } else {
      start_dt.push('-');
    }

    if (this.param_enddt && this.param_enddt != '' && this.param_enddt != undefined) {
      end_dt.push(this.param_enddt);
    } else {
      end_dt.push('-');
    }

    if (this.param_good[0] != '' && this.param_good[0] != undefined && this.param_good.length > 0) {
      good.push(this.param_good.join());
    } else {
      good.push('-');
    }

    if (this.param_bad[0] != '' && this.param_bad[0] != undefined && this.param_bad.length > 0) {
      bad.push(this.param_bad.join());
    } else {
      bad.push('-');
    }

    if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
      ind.push(this.param_inter.join());
    } else {
      ind.push('-');
    }

    if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
      loss.push(this.param_loss.join());
    } else {
      loss.push('-');
    }

    if (this.param_archdt != '' && this.param_archdt != undefined) {
      archdt.push(this.param_archdt);
    } else {
      archdt.push('-');
    }

    if (this.param_appldtcol && this.param_appldtcol != '' && this.param_appldtcol != undefined) {
      appln_dt.push(this.param_appldtcol);
    } else {
      appln_dt.push('-');
    }

    var subid: any = [];

    for (var i = 0; i < this.subscriber_det.length; i++) {
      subid.push({ count: [this.subscriber_det[i]['count']], name: [this.subscriber_det[i]['name']] });
    }

    var data: any = {
      tab2: this.scre_exprt_arry,
      company_name: cmpny_arry,
      porttype: porttype,
      start_dt: start_dt,
      end_dt: end_dt,
      good: good,
      bad: bad,
      ind: ind,
      loss: loss,
      archdt: archdt,
      appln_dt: appln_dt,
      subscriber: subid
    };
    this.chartservice.Getscorechart_table_exprt(data).subscribe((apiresponse: any) => {
      const blob = new Blob([apiresponse], {
        type: 'application/vnd.ms.excel'
      });

      var downloadURL = window.URL.createObjectURL(apiresponse);
      var link = document.createElement('a');
      link.href = downloadURL;
      var filename: any = 'score_performance' + date;
      link.download = filename + '.xlsx';
      link.click();

      if (apiresponse) {
      }
    });
  }

  radioCustmChange(event: any) {
    // console.log(event)
    if (this.Radio_pchart == '1') {
      this.custm_disable = false;
      this.lwrrange_disable = true;

      this.Pchart_customrange = this.Pchart_customrange;
      this.min_range = null;
      this.max_range = null;
      this.low_range = null;
    } else {
      this.custm_disable = true;
      this.lwrrange_disable = false;
      this.Pchart_customrange = null;
      this.Pcharts_value();
      this.min_range = this.min_range;
      this.max_range = this.max_range;
      this.low_range = this.low_range;
    }
  }

  Getscorecharts(data: any) {
    this.chartservice.Getscore_tab(data).subscribe((apiresponse: any) => {
      if (apiresponse) {
        console.log(apiresponse['score_charts'][0]);
        this.scre_exprt_arry = apiresponse['score_charts'][0];

        var gooddata: any = [];
        gooddata = apiresponse['score_charts'][0]['KS-chart'][0];

        var ginidata: any = [];
        ginidata = apiresponse['score_charts'][0]['Gini-chart'][0];

        var badtendata: any = [];
        badtendata = apiresponse['score_charts'][0]['bad10-chart'][0];

        var badtencntdata: any = [];
        badtencntdata = apiresponse['score_charts'][0]['bad10-count-chart'][0];

        var badtwedata: any = [];
        badtwedata = apiresponse['score_charts'][0]['bad20-chart'][0];

        var badtwecntdata: any = [];
        badtwecntdata = apiresponse['score_charts'][0]['bad20-count-chart'][0];

        var badthirdata: any = [];
        badthirdata = apiresponse['score_charts'][0]['bad30-chart'][0];

        var badthircntdata: any = [];
        badthircntdata = apiresponse['score_charts'][0]['bad30-count-chart'][0];

        var totalcntdata: any = [];
        totalcntdata = apiresponse['score_charts'][0]['total-count'][0];

        this.good_bad(gooddata);
        this.Gini(ginidata);

        this.worst_capture_number(badtendata);
        this.worst_capture_percent(badtencntdata);

        this.worst_capture_number_20(badtwedata);
        this.worst_capture_percent_20(badtwecntdata);
        this.worst_capture_number_30(badthirdata);
        this.worst_capture_percent_30(badthircntdata);
        this.total_counts(totalcntdata);
      }
    });
  }

  Scorecmprison_Refresh() {
    let data: any = {
      company_name: this.Summary_CompanyName,
      portfolio_type: this.sum_trdtype,
      scores: this.score_model
    };

    this.GetScrecmpr_chart(data);
  }

  screcmpr_exprt: any = [];

  GetScrecmpr_chart(data: any) {
    this.compar_tbl = [];
    this.scre_cmp_col = [];

    this.chartservice.Getscrecmpr_table(data).subscribe((apiresponse: any) => {
      console.log(apiresponse);
      if (apiresponse) {
        var scre_cmpr = apiresponse['scre_cmpr'][0];

        this.screcmpr_exprt = apiresponse;

        for (var i = 0; i < scre_cmpr['scores'].length; i++) {
          this.scre_cmp_col.push(scre_cmpr['scores'][i]);
        }

        var screcomparison_tbl3: any = Object.keys(scre_cmpr);

        this.scre_no = this.scre_cmp_col.length;
        var cmpr_tbl: any = [];

        for (var i = 0; i < screcomparison_tbl3.length; i++) {
          if (screcomparison_tbl3[i] != 'scores') {
            this.compar_tbl.push(scre_cmpr[screcomparison_tbl3[i]]);
          }
        }
        console.log(this.compar_tbl);
      }
    });
  }

  GetScrecmpr_chart_exprt() {
    var cmpny_arry: any = [];
    cmpny_arry.push(this.Summary_CompanyName);
    var porttype: any = [];
    var scre_arry: any = [];

    var archdt: any = [];
    var start_dt: any = [];
    var end_dt: any = [];
    var good: any = [];
    var bad: any = [];
    var ind: any = [];
    var loss: any = [];
    var appln_dt: any = [];

    if (this.param_startdt && this.param_startdt != '' && this.param_startdt != undefined) {
      start_dt.push(this.param_startdt);
    } else {
      start_dt.push('-');
    }

    if (this.param_enddt && this.param_enddt != '' && this.param_enddt != undefined) {
      end_dt.push(this.param_enddt);
    } else {
      end_dt.push('-');
    }

    if (this.param_good[0] != '' && this.param_good[0] != undefined && this.param_good.length > 0) {
      good.push(this.param_good.join());
    } else {
      good.push('-');
    }

    if (this.param_bad[0] != '' && this.param_bad[0] != undefined && this.param_bad.length > 0) {
      bad.push(this.param_bad.join());
    } else {
      bad.push('-');
    }

    if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
      ind.push(this.param_inter.join());
    } else {
      ind.push('-');
    }

    if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
      loss.push(this.param_loss.join());
    } else {
      loss.push('-');
    }

    if (this.param_archdt != '' && this.param_archdt != undefined) {
      archdt.push(this.param_archdt);
    } else {
      archdt.push('-');
    }

    if (this.param_appldtcol && this.param_appldtcol != '' && this.param_appldtcol != undefined) {
      appln_dt.push(this.param_appldtcol);
    } else {
      appln_dt.push('-');
    }

    for (var i = 0; i < this.sum_trdtype.length; i++) {
      porttype.push(this.sum_trdtype[i]['item_id']);
    }

    for (var i = 0; i < this.score_model.length; i++) {
      scre_arry.push(this.score_model[i]['item_id_scores']);
    }

    var date = this.getdatetime();
    var subid: any = [];

    for (var i = 0; i < this.subscriber_det.length; i++) {
      subid.push({ count: [this.subscriber_det[i]['count']], name: [this.subscriber_det[i]['name']] });
    }

    var data: any = {
      tab3: this.screcmpr_exprt,
      company_name: cmpny_arry,
      porttype: porttype,
      scores: scre_arry,
      start_dt: start_dt,
      end_dt: end_dt,
      good: good,
      bad: bad,
      ind: ind,
      loss: loss,
      archdt: archdt,
      appln_dt: appln_dt,
      subscriber: subid
    };
    this.chartservice.Getscresummry_table_exprt(data).subscribe((apiresponse: any) => {
      const blob = new Blob([apiresponse], {
        type: 'application/vnd.ms.excel'
      });

      var downloadURL = window.URL.createObjectURL(apiresponse);
      var link = document.createElement('a');
      link.href = downloadURL;
      var filename: any = 'score_comparison' + date;
      link.download = filename + '.xlsx';
      link.click();

      if (apiresponse) {
      }
    });
  }

  param_cmpny_ascend: boolean;
  param_cmpny_client: boolean;

  param_company: any;
  param_subid: any;
  param_startdt: any;
  param_enddt: any;
  param_mnth: any;
  param_year: any;
  param_perwind: any;
  param_pubrec: any;
  param_collrec: any;

  param_good: any = [];
  param_bad: any = [];
  param_inter: any = [];
  param_loss: any = [];

  param_archdt: any;

  parm_schema: any = [];
  parm_scorename: any = [];
  parm_table: any = [];
  parm_screcol: any = [];
  parm_low: any = [];
  parm_high: any = [];
  parm_sortorder: any = [];
  parm_tabledata: any = [];

  param_dir: any;
  parm_clienttable: any = [];
  param_uniqueid: any;
  param_appldtcol: any;
  param_appldtfrmt: any;
  param_stdt: any;
  param_clinetenddt: any;
  param_appldeccol: any;
  param_dectype: any = [];
  param_booked: any = [];
  param_approvd: any = [];
  param_declined: any = [];
  param_percol: any;
  param_prdtcol: any;
  param_trdtypeval: any = [];

  parm_client_scorename: any = [];
  parm_client_screcol: any = [];
  parm_client_low: any = [];
  parm_client_high: any = [];
  parm_client_sortorder: any = [];

  GetParamtabledata(data: any) {
    console.log(data);
    var tab_length: any = [];

    var clnttbl: any = [];
    clnttbl = data.tbl_name;

    var dectype: any = [];
    dectype = data.dec_type;

    var booked: any = [];
    booked = data.booked;

    var approvd_bookd: any = [];
    approvd_bookd = data.apprvd_bookd;

    var declined: any = [];
    declined = data.declined;

    if (data.company_type == 'ascend table') {
      this.param_cmpny_ascend = true;
      this.param_cmpny_client = false;

      var Getcmpny_sub: any = [];
      Getcmpny_sub = JSON.parse(localStorage.getItem('company_subid') || '[]');

      this.param_company = Getcmpny_sub;
      this.param_subid = Object.values(data.subcriber_id);

      this.param_pubrec = data.public_rec;
      this.param_collrec = data.collection_rec;

      this.param_startdt = data.start_dt;
      this.param_enddt = data.end_dt;
      this.param_mnth = data.per_snap_mnth;
      this.param_year = data.per_snap_year;

      this.param_perwind = data.per_wind;
      this.param_archdt = data.archivedt;

      for (var j = 0; j < this.parm_table.length; j++) {
        this.parm_tabledata.push(this.parm_table[j][0]['item_id_scretbl']);
      }
    } else {
      this.param_cmpny_ascend = false;
      this.param_cmpny_client = true;

      this.param_company = data.company_name;
      this.param_dir = data.directory;

      this.parm_clienttable.push(clnttbl[0]['item_id_srch']);
      this.param_uniqueid = data.uniquecust_col;
      this.param_appldtcol = data.appln_date_col;
      this.param_appldtfrmt = data.appln_dt_format;
      this.param_startdt = data.start_dt;
      this.param_enddt = data.end_dt;
      this.param_appldeccol = data.appln_dec_col;
      this.param_archdt = data.archivedt;

      var trademaingrp: any = [];

      var tradetype: any = [];
      tradetype = Object.keys(data.trade_type);

      var tradetypeval: any = [];
      tradetypeval = Object.keys(data.trade_val);

      for (var i = 0; i < tradetype.length; i++) {
        var tdvl: any = [];

        // debugger;
        var tdvl_index: any;
        if (data.trade_val[tradetypeval[i]] != null && data.trade_val[tradetypeval[i]] != 'null') {
          tdvl_index = Object.keys(data.trade_val[tradetypeval[i]]);

          for (var k = 0; k < tdvl_index.length; k++) {
            tdvl.push(data.trade_val[tradetypeval[i]][k]['item_id_trd']);
          }

          var value_trd: any = tdvl.join();
          var fin_val_tr: any = data.trade_type[tradetype[i]] + '(' + value_trd + ')';

          trademaingrp.push({
            name: fin_val_tr
          });

          for (var l = 0; l < trademaingrp.length; l++) {
            this.param_trdtypeval.push(trademaingrp[l]['name']);
            this.param_trdtypeval.join();
          }

          if (this.param_trdtypeval[0] == '0()' || this.param_trdtypeval[0] == '()') {
            this.param_trdtypeval = [];
          }
        }
      }

      for (var j = 0; j < booked.length; j++) {
        this.param_booked.push(booked[j]['item_id_book']);
      }

      for (var j = 0; j < approvd_bookd.length; j++) {
        this.param_approvd.push(approvd_bookd[j]['item_id_apprvd']);
      }

      for (var j = 0; j < declined.length; j++) {
        this.param_declined.push(declined[j]['item_id_decl']);
      }

      this.param_percol = data.performance_col;
      this.param_prdtcol = data.trade_col;

      this.parm_client_scorename = Object.values(data.scorename);
      this.parm_client_screcol = Object.values(data.scorecol);
      this.parm_client_low = Object.values(data.vallow);
      this.parm_client_high = Object.values(data.valhigh);

      var client_rev = Object.values(data.reverse);

      for (var j = 0; j < client_rev.length; j++) {
        if (client_rev[j] == 'Y' || client_rev[j] == 'y') {
          this.parm_client_sortorder.push('Low to High');
        } else {
          this.parm_client_sortorder.push('High to Low');
        }
      }
    }
    let tbl: any = [];
    this.parm_schema = Object.values(data.scre_score_scehma);
    tab_length = Object.keys(data.scre_score_table);
    for (var i = 0; i < tab_length.length; i++) {
      this.parm_table.push(data.scre_score_table[tab_length[i]]);
    }

    for (var j = 0; j < this.parm_table.length; j++) {
      this.parm_tabledata.push(this.parm_table[j][0]['item_id_scretbl']);
    }

    this.parm_scorename = Object.values(data.scre_score_name);
    this.parm_screcol = Object.values(data.scre_score_col);
    this.parm_low = Object.values(data.scre_val_low);
    this.parm_high = Object.values(data.scre_val_high);

    var scrsort_yes_no = Object.values(data.scre_rev);
    for (var j = 0; j < scrsort_yes_no.length; j++) {
      if (scrsort_yes_no[j] == 'Y' || scrsort_yes_no[j] == 'y') {
        this.parm_sortorder.push('Low to High');
      } else {
        this.parm_sortorder.push('High to Low');
      }
    }

    for (var i = 0; i < data.good.length; i++) {
      this.param_good.push(data.good[i]['item_id_gd']);
    }

    for (var i = 0; i < data.bad.length; i++) {
      this.param_bad.push(data.bad[i]['item_id_bd']);
    }

    for (var i = 0; i < data.indeteminant.length; i++) {
      this.param_inter.push(data.indeteminant[i]['item_id_inter']);
    }

    for (var i = 0; i < data.loss.length; i++) {
      this.param_loss.push(data.loss[i]['item_id_los']);
    }
  }

  Getparam_export() {
    var GetData: any = [];
    GetData = JSON.parse(localStorage.getItem('retrivedata') || '[]');
    let paramval: any;

    if (GetData.company_type == 'ascend table') {
      var cmpny_singlarry: any = [];
      var subid_singlarry: any = [];
      var startdt: any = [];
      var enddt: any = [];
      var exp_trd_mnth: any = [];
      var exp_trd_year: any = [];
      var pub_rec: any = [];
      var coll_rec: any = [];
      var good_singlarry: any = [];
      var bad_singlarry: any = [];
      var indeter_singlarry: any = [];
      var loss_singlarry: any = [];
      var perf_window: any = [];

      var archdt: any = [];
      var scre_scre_name_sinarry: any = [];
      var scre_scre_schema_sinarry: any = [];
      var scre_scre_table_sinarry: any = [];
      var scre_scre_col_sinarry: any = [];
      var scre_scre_low_sinarry: any = [];
      var scre_scre_high_sinarry: any = [];
      var scre_scre_srtorder_sinarry: any = [];

      cmpny_singlarry.push(this.param_company.join());

      subid_singlarry.push(this.param_subid.join());
      startdt.push(this.param_startdt);
      enddt.push(this.param_enddt);
      exp_trd_mnth.push(this.param_mnth);
      exp_trd_year.push(this.param_year);
      pub_rec.push(this.param_pubrec);
      coll_rec.push(this.param_collrec);
      good_singlarry.push(this.param_good.join());
      bad_singlarry.push(this.param_bad.join());

      if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
        indeter_singlarry.push(this.param_inter.join());
      } else {
        indeter_singlarry.push('-');
      }

      if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
        loss_singlarry.push(this.param_loss.join());
      } else {
        loss_singlarry.push('-');
      }

      archdt.push(this.param_archdt);
      scre_scre_name_sinarry.push(this.parm_scorename.join());
      scre_scre_schema_sinarry.push(this.parm_schema.join());
      scre_scre_table_sinarry.push(this.parm_tabledata.join());
      scre_scre_col_sinarry.push(this.parm_screcol.join());
      scre_scre_low_sinarry.push(this.parm_low.join());
      scre_scre_high_sinarry.push(this.parm_high.join());
      scre_scre_srtorder_sinarry.push(this.parm_sortorder.join());
      perf_window.push(this.param_perwind);

      paramval = {
        company_type: 'Ascend Table',
        company_name: cmpny_singlarry,
        subid: subid_singlarry,

        perfrm_win: perf_window,
        start_dt: startdt,
        end_dt: enddt,
        exp_trd_month: exp_trd_mnth,
        exp_trd_year: exp_trd_year,
        public_rec: pub_rec,
        collection_rec: coll_rec,

        good: good_singlarry,
        indeterminant: indeter_singlarry,
        bad: bad_singlarry,
        loss: loss_singlarry,

        arch_date: archdt,
        scre_scre_name: scre_scre_name_sinarry,
        scre_scre_schema: scre_scre_schema_sinarry,
        scre_scre_table: scre_scre_table_sinarry,
        scre_scre_column: scre_scre_col_sinarry,
        scre_scre_low: scre_scre_low_sinarry,
        scre_scre_high: scre_scre_high_sinarry,
        scre_scre_sortorder: scre_scre_srtorder_sinarry
      };
    } else {
      let cmpny_array: any = [];

      cmpny_array.push(this.param_company);

      var strtdt: any = [];
      var enddt: any = [];
      var dir: any = [];
      var clienttable: any = [];
      var uniqueid: any = [];
      var applndtcol: any = [];
      var appln_date_frmt: any = [];
      var appln_dec_col: any = [];
      var dec_type: any = [];
      var booked: any = [];
      var apprvd: any = [];
      var decline: any = [];
      var perfmncol: any = [];
      var prdcol: any = [];
      var porttypval: any = [];

      var good_singlarry: any = [];
      var bad_singlarry: any = [];
      var indeter_singlarry: any = [];
      var loss_singlarry: any = [];

      var archdt: any = [];
      var scre_scre_name_sinarry: any = [];
      var scre_scre_schema_sinarry: any = [];
      var scre_scre_table_sinarry: any = [];
      var scre_scre_col_sinarry: any = [];
      var scre_scre_low_sinarry: any = [];
      var scre_scre_high_sinarry: any = [];
      var scre_scre_srtorder_sinarry: any = [];

      var clientscrname_singlarry: any = [];
      var clientscrcolsinglarry: any = [];
      var clientscrnlow_singlarry: any = [];
      var clienthigh_singlarry: any = [];
      var clientlow_singlarry: any = [];
      var clientsort_singlarry: any = [];

      if (this.param_stdt != '' && this.param_stdt != undefined) {
        strtdt.push(this.param_stdt);
      } else {
        strtdt.push('-');
      }

      if (this.param_clinetenddt != '' && this.param_clinetenddt != undefined) {
        enddt.push(this.param_clinetenddt);
      } else {
        enddt.push('-');
      }

      if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
        loss_singlarry.push(this.param_loss.join());
      } else {
        loss_singlarry.push('-');
      }

      if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
        indeter_singlarry.push(this.param_inter.join());
      } else {
        indeter_singlarry.push('-');
      }

      if (this.param_percol[0] != '' && this.param_percol[0] != undefined) {
        perfmncol.push(this.param_percol);
      } else {
        perfmncol.push('-');
      }

      if (this.param_prdtcol != '' && this.param_prdtcol[0] != undefined) {
        prdcol.push(this.param_prdtcol);
      } else {
        prdcol.push('-');
      }

      if (this.param_prdtcol != '' && this.param_prdtcol[0] != undefined) {
        porttypval.push(this.param_trdtypeval.join());
      } else if (porttypval == '0()' || porttypval != '') {
        porttypval.push(this.param_trdtypeval.join());
      } else {
        porttypval.push('-');
      }

      if (this.parm_client_scorename[0] != '' && this.parm_client_scorename[0] != undefined) {
        clientscrname_singlarry.push(this.parm_client_scorename.join());
      } else {
        clientscrname_singlarry.push('-');
      }

      if (this.parm_screcol[0] != '' && this.parm_screcol[0] != undefined) {
        clientscrcolsinglarry.push(this.parm_client_screcol.join());
      } else {
        clientscrcolsinglarry.push('-');
      }

      if (this.parm_client_low[0] != '' && this.parm_client_low[0] != undefined) {
        clientscrnlow_singlarry.push(this.parm_client_low.join());
      } else {
        clientscrnlow_singlarry.push('-');
      }

      if (this.parm_client_high[0] != '' && this.parm_client_high[0] != undefined) {
        clienthigh_singlarry.push(this.parm_client_high.join());
      } else {
        clienthigh_singlarry.push('-');
      }

      if (this.parm_client_sortorder[0] != '' && this.parm_client_sortorder[0] != undefined) {
        clientsort_singlarry.push(this.parm_client_sortorder.join());
      } else {
        clientsort_singlarry.push('-');
      }

      dir.push(this.param_dir);
      clienttable.push(this.parm_clienttable);
      uniqueid.push(this.param_uniqueid);
      applndtcol.push(this.param_appldtcol);
      appln_date_frmt.push(this.param_appldtfrmt);
      appln_dec_col.push(this.param_appldeccol);

      // dec_type.push(this.param_dectype.join());
      booked.push(this.param_booked.join());
      apprvd.push(this.param_approvd.join());
      decline.push(this.param_declined.join());

      good_singlarry.push(this.param_good.join());
      bad_singlarry.push(this.param_bad.join());
      archdt.push(this.param_archdt);
      scre_scre_name_sinarry.push(this.parm_scorename.join());
      scre_scre_schema_sinarry.push(this.parm_schema.join());
      scre_scre_table_sinarry.push(this.parm_tabledata.join());
      scre_scre_col_sinarry.push(this.parm_screcol.join());
      scre_scre_low_sinarry.push(this.parm_low.join());
      scre_scre_high_sinarry.push(this.parm_high.join());
      scre_scre_srtorder_sinarry.push(this.parm_sortorder.join());

      paramval = {
        company_type: 'Client Table',
        company_name: cmpny_array,
        directory: dir,
        tablename: this.parm_clienttable,
        uniquerecordid: uniqueid,
        appln_date_column: applndtcol,
        appln_date_frmt: appln_date_frmt,
        start_dt: strtdt,
        end_dt: enddt,
        appln_dec_col: appln_dec_col,
        decision_type: dec_type,
        booked: booked,
        approved_not_booked: apprvd,
        declined: decline,
        performance_col: perfmncol,
        good: good_singlarry,
        indeterminant: indeter_singlarry,
        bad: bad_singlarry,
        loss: loss_singlarry,
        product_column: prdcol,
        portfoli_type_value: porttypval,
        scre_name: clientscrname_singlarry,
        scre_column: clientscrnlow_singlarry,
        valid_low: clientscrnlow_singlarry,
        valid_high: clienthigh_singlarry,
        sort_order: clientsort_singlarry,
        arch_date: archdt,
        scre_scre_name: scre_scre_name_sinarry,
        scre_scre_schema: scre_scre_schema_sinarry,
        scre_scre_table: scre_scre_table_sinarry,
        scre_scre_column: scre_scre_col_sinarry,
        scre_scre_low: scre_scre_low_sinarry,
        scre_scre_high: scre_scre_high_sinarry,
        scre_scre_sortorder: scre_scre_srtorder_sinarry
      };
    }

    var data: any = {
      tab6: paramval
    };
    var date = this.getdatetime();

    this.chartservice.Getparameters_table_exprt(data).subscribe((apiresponse: any) => {
      const blob = new Blob([apiresponse], {
        type: 'application/vnd.ms.excel'
      });

      var downloadURL = window.URL.createObjectURL(apiresponse);
      var link = document.createElement('a');
      link.href = downloadURL;
      var filename: any = 'parameter' + date;
      link.download = filename + '.xlsx';
      link.click();

      if (apiresponse) {
      }
    });
  }

  Getparam_export_master() {
    var GetData: any = [];
    GetData = JSON.parse(localStorage.getItem('retrivedata') || '[]');
    let paramval: any;

    if (GetData.company_type == 'ascend table') {
      var cmpny_singlarry: any = [];
      var subid_singlarry: any = [];
      var startdt: any = [];
      var enddt: any = [];
      var exp_trd_mnth: any = [];
      var exp_trd_year: any = [];
      var pub_rec: any = [];
      var coll_rec: any = [];
      var good_singlarry: any = [];
      var bad_singlarry: any = [];
      var indeter_singlarry: any = [];
      var loss_singlarry: any = [];
      var perf_window: any = [];

      var archdt: any = [];
      var scre_scre_name_sinarry: any = [];
      var scre_scre_schema_sinarry: any = [];
      var scre_scre_table_sinarry: any = [];
      var scre_scre_col_sinarry: any = [];
      var scre_scre_low_sinarry: any = [];
      var scre_scre_high_sinarry: any = [];
      var scre_scre_srtorder_sinarry: any = [];

      cmpny_singlarry.push(this.param_company.join());

      subid_singlarry.push(this.param_subid.join());
      startdt.push(this.param_startdt);
      enddt.push(this.param_enddt);
      exp_trd_mnth.push(this.param_mnth);
      exp_trd_year.push(this.param_year);
      pub_rec.push(this.param_pubrec);
      coll_rec.push(this.param_collrec);
      good_singlarry.push(this.param_good.join());
      bad_singlarry.push(this.param_bad.join());

      if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
        indeter_singlarry.push(this.param_inter.join());
      } else {
        indeter_singlarry.push('-');
      }

      if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
        loss_singlarry.push(this.param_loss.join());
      } else {
        loss_singlarry.push('-');
      }

      archdt.push(this.param_archdt);
      scre_scre_name_sinarry.push(this.parm_scorename.join());
      scre_scre_schema_sinarry.push(this.parm_schema.join());
      scre_scre_table_sinarry.push(this.parm_tabledata.join());
      scre_scre_col_sinarry.push(this.parm_screcol.join());
      scre_scre_low_sinarry.push(this.parm_low.join());
      scre_scre_high_sinarry.push(this.parm_high.join());
      scre_scre_srtorder_sinarry.push(this.parm_sortorder.join());
      perf_window.push(this.param_perwind);

      paramval = {
        company_type: 'Ascend Table',
        company_name: cmpny_singlarry,
        subid: subid_singlarry,

        perfrm_win: perf_window,
        start_dt: startdt,
        end_dt: enddt,
        exp_trd_month: exp_trd_mnth,
        exp_trd_year: exp_trd_year,
        public_rec: pub_rec,
        collection_rec: coll_rec,

        good: good_singlarry,
        indeterminant: indeter_singlarry,
        bad: bad_singlarry,
        loss: loss_singlarry,

        arch_date: archdt,
        scre_scre_name: scre_scre_name_sinarry,
        scre_scre_schema: scre_scre_schema_sinarry,
        scre_scre_table: scre_scre_table_sinarry,
        scre_scre_column: scre_scre_col_sinarry,
        scre_scre_low: scre_scre_low_sinarry,
        scre_scre_high: scre_scre_high_sinarry,
        scre_scre_sortorder: scre_scre_srtorder_sinarry
      };
    } else {
      let cmpny_array: any = [];

      cmpny_array.push(this.param_company);

      var strtdt: any = [];
      var enddt: any = [];
      var dir: any = [];
      var clienttable: any = [];
      var uniqueid: any = [];
      var applndtcol: any = [];
      var appln_date_frmt: any = [];
      var appln_dec_col: any = [];
      var dec_type: any = [];
      var booked: any = [];
      var apprvd: any = [];
      var decline: any = [];
      var perfmncol: any = [];
      var prdcol: any = [];
      var porttypval: any = [];

      var good_singlarry: any = [];
      var bad_singlarry: any = [];
      var indeter_singlarry: any = [];
      var loss_singlarry: any = [];

      var archdt: any = [];
      var scre_scre_name_sinarry: any = [];
      var scre_scre_schema_sinarry: any = [];
      var scre_scre_table_sinarry: any = [];
      var scre_scre_col_sinarry: any = [];
      var scre_scre_low_sinarry: any = [];
      var scre_scre_high_sinarry: any = [];
      var scre_scre_srtorder_sinarry: any = [];

      var clientscrname_singlarry: any = [];
      var clientscrcolsinglarry: any = [];
      var clientscrnlow_singlarry: any = [];
      var clienthigh_singlarry: any = [];
      var clientlow_singlarry: any = [];
      var clientsort_singlarry: any = [];

      if (this.param_stdt != '' && this.param_stdt != undefined) {
        strtdt.push(this.param_stdt);
      } else {
        strtdt.push('-');
      }

      if (this.param_clinetenddt != '' && this.param_clinetenddt != undefined) {
        enddt.push(this.param_clinetenddt);
      } else {
        enddt.push('-');
      }

      if (this.param_loss[0] != '' && this.param_loss[0] != undefined && this.param_loss.length > 0) {
        loss_singlarry.push(this.param_loss.join());
      } else {
        loss_singlarry.push('-');
      }

      if (this.param_inter[0] != '' && this.param_inter[0] != undefined && this.param_inter.length > 0) {
        indeter_singlarry.push(this.param_inter.join());
      } else {
        indeter_singlarry.push('-');
      }

      if (this.param_percol[0] != '' && this.param_percol[0] != undefined) {
        perfmncol.push(this.param_percol);
      } else {
        perfmncol.push('-');
      }

      if (this.param_prdtcol != '' && this.param_prdtcol[0] != undefined) {
        prdcol.push(this.param_prdtcol);
      } else {
        prdcol.push('-');
      }

      if (this.param_prdtcol != '' && this.param_prdtcol[0] != undefined) {
        porttypval.push(this.param_trdtypeval.join());
      } else if (porttypval == '0()' || porttypval != '') {
        porttypval.push(this.param_trdtypeval.join());
      } else {
        porttypval.push('-');
      }

      if (this.parm_client_scorename[0] != '' && this.parm_client_scorename[0] != undefined) {
        clientscrname_singlarry.push(this.parm_client_scorename.join());
      } else {
        clientscrname_singlarry.push('-');
      }

      if (this.parm_screcol[0] != '' && this.parm_screcol[0] != undefined) {
        clientscrcolsinglarry.push(this.parm_client_screcol.join());
      } else {
        clientscrcolsinglarry.push('-');
      }

      if (this.parm_client_low[0] != '' && this.parm_client_low[0] != undefined) {
        clientscrnlow_singlarry.push(this.parm_client_low.join());
      } else {
        clientscrnlow_singlarry.push('-');
      }

      if (this.parm_client_high[0] != '' && this.parm_client_high[0] != undefined) {
        clienthigh_singlarry.push(this.parm_client_high.join());
      } else {
        clienthigh_singlarry.push('-');
      }

      if (this.parm_client_sortorder[0] != '' && this.parm_client_sortorder[0] != undefined) {
        clientsort_singlarry.push(this.parm_client_sortorder.join());
      } else {
        clientsort_singlarry.push('-');
      }

      dir.push(this.param_dir);
      clienttable.push(this.parm_clienttable);
      uniqueid.push(this.param_uniqueid);
      applndtcol.push(this.param_appldtcol);
      appln_date_frmt.push(this.param_appldtfrmt);
      appln_dec_col.push(this.param_appldeccol);

      // dec_type.push(this.param_dectype.join());
      booked.push(this.param_booked.join());
      apprvd.push(this.param_approvd.join());
      decline.push(this.param_declined.join());

      good_singlarry.push(this.param_good.join());
      bad_singlarry.push(this.param_bad.join());
      archdt.push(this.param_archdt);
      scre_scre_name_sinarry.push(this.parm_scorename.join());
      scre_scre_schema_sinarry.push(this.parm_schema.join());
      scre_scre_table_sinarry.push(this.parm_tabledata.join());
      scre_scre_col_sinarry.push(this.parm_screcol.join());
      scre_scre_low_sinarry.push(this.parm_low.join());
      scre_scre_high_sinarry.push(this.parm_high.join());
      scre_scre_srtorder_sinarry.push(this.parm_sortorder.join());

      paramval = {
        company_type: 'Client Table',
        company_name: cmpny_array,
        directory: dir,
        tablename: this.parm_clienttable,
        uniquerecordid: uniqueid,
        appln_date_column: applndtcol,
        appln_date_frmt: appln_date_frmt,
        start_dt: strtdt,
        end_dt: enddt,
        appln_dec_col: appln_dec_col,
        decision_type: dec_type,
        booked: booked,
        approved_not_booked: apprvd,
        declined: decline,
        performance_col: perfmncol,
        good: good_singlarry,
        indeterminant: indeter_singlarry,
        bad: bad_singlarry,
        loss: loss_singlarry,
        product_column: prdcol,
        portfoli_type_value: porttypval,
        scre_name: clientscrname_singlarry,
        scre_column: clientscrnlow_singlarry,
        valid_low: clientscrnlow_singlarry,
        valid_high: clienthigh_singlarry,
        sort_order: clientsort_singlarry,
        arch_date: archdt,
        scre_scre_name: scre_scre_name_sinarry,
        scre_scre_schema: scre_scre_schema_sinarry,
        scre_scre_table: scre_scre_table_sinarry,
        scre_scre_column: scre_scre_col_sinarry,
        scre_scre_low: scre_scre_low_sinarry,
        scre_scre_high: scre_scre_high_sinarry,
        scre_scre_sortorder: scre_scre_srtorder_sinarry
      };
    }

    let prmvl: any = [];
    prmvl.push(paramval);

    return prmvl;
  }
}
