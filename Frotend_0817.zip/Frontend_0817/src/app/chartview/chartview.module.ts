import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { MatCardModule, MatGridListModule, MatButtonModule } from '@angular/material';
import { ChartRoutingModule } from './chartview.routing.module';
import { ChartviewComponent } from './chartview.component';
import { ChartsModule } from 'ng2-charts';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { ChartService } from './chartview.service';

@NgModule({
  imports: [
    ChartsModule,
    MatCardModule,
    MatGridListModule,
    CommonModule,
    TranslateModule,
    ChartRoutingModule,
    NgMultiSelectDropDownModule,
    FormsModule,
    ReactiveFormsModule,
    MatRadioModule
  ],
  declarations: [ChartviewComponent],
  providers: [ChartService]
})
export class ChartviewModule {}
