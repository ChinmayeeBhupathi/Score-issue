export class AppSettings {
  public static experian = 'http://10.28.220.81:5000/';
  public static octagon = 'http://10.28.220.81:5000/';
}
