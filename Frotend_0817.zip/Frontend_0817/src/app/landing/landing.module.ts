import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { MatCardModule, MatGridListModule, MatButtonModule } from '@angular/material';
import { LandRoutingModule } from './landing.routing.module';
import { LandingComponent } from './landing.component';
import { FormsModule } from '@angular/forms';
import { MatSortModule } from '@angular/material/sort';

@NgModule({
  imports: [
    MatCardModule,
    MatGridListModule,
    CommonModule,
    TranslateModule,
    LandRoutingModule,
    FormsModule,
    MatSortModule
  ],
  declarations: [LandingComponent]
})
export class LandingModule {}
