import { Component, OnInit } from '@angular/core';
import { AppSettings } from 'app/app.constant';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {
  getusername: any;
  urltoexp: any;
  urltooct: any;

  constructor() {}

  ngOnInit() {
    this.getusername = localStorage.getItem('username');
    this.urltoexp = AppSettings.experian + 'home';
    this.urltooct = AppSettings.octagon + 'home';
    // this.urltooct = AppSettings.octagon +"home?name="+this.getusername;
  }
}
