import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService, I18nService } from '@app/core';
import { AppSettings } from 'app/app.constant';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  menuHidden = true;
  usernm: any;
  urltoexp: any;

  constructor(
    private route: Router,
    private router: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private i18nService: I18nService,
    private httpClient: HttpClient
  ) {}

  ngOnInit() {
    console.log(this.router.snapshot.queryParamMap.get('name'));
    localStorage.setItem('name', this.router.snapshot.queryParamMap.get('name'));

    this.usernm = localStorage.getItem('name');
    this.urltoexp = AppSettings.experian + 'login';
  }

  toggleMenu() {
    this.menuHidden = !this.menuHidden;
  }

  setLanguage(language: string) {
    this.i18nService.language = language;
  }

  logout() {
    this.httpClient.post('logout', {}).subscribe(
      (val: any) => {
        console.log(val);
        if (val.status == true || val.status == 'true') {
          console.log(val);
          localStorage.clear();
          this.authenticationService.logout().subscribe(() => this.route.navigate(['/login'], { replaceUrl: true }));
        }
      },

      () => {}
    );
  }

  get currentLanguage(): string {
    return this.i18nService.language;
  }

  get languages(): string[] {
    return this.i18nService.supportedLanguages;
  }

  get username(): string | null {
    const credentials = this.authenticationService.credentials;
    return credentials ? credentials['token'] : null;
  }
}
