import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { AuthenticationService } from '../authentication/authentication.service';
import { catchError, finalize } from 'rxjs/operators';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

/**
 * Prefixes all requests with `environment.serverUrl`.
 */
@Injectable()
export class ApiPrefixInterceptor implements HttpInterceptor {
  constructor(
    private AuthService: AuthenticationService,
    private ngxService: NgxUiLoaderService,
    private route: Router,
    private authenticationService: AuthenticationService // private httpClient: HttpClient
  ) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.ngxService.start();
    let headers;

    if (request.url == '/login' || request.url == '/logout') {
      headers = request.headers
        .set('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT')
        .set('Access-Control-Allow-Origin', '*');
    } else {
      headers = request.headers
        .set('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT')
        .set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `${this.AuthService.getToken()}`);
    }
    if (environment.production == false) {
      request = request.clone({
        headers,
        url: environment.serverUrl + request.url
      });
    } else {
      request = request.clone({
        headers,
        url: environment.LiveUrl + request.url
      });
    }
    return next.handle(request).pipe(
      catchError(error => {
        if (error.status === 403) {
          localStorage.clear();
          window.location.href = '/login';
        }

        // console.log('error occured:', error);
        throw error;
      }),
      finalize(() => {
        this.ngxService.stop();
      })
    );
  }

  // logout() {
  //   this.httpClient.post('logout', {}).subscribe(
  //     (val: any) => {
  //       console.log(val);
  //       if (val.status == true || val.status == 'true') {
  //         console.log(val);
  //         localStorage.clear();
  //         this.authenticationService.logout().subscribe(() => this.route.navigate(['/login'], { replaceUrl: true }));
  //       }
  //     },

  //     () => {}
  //   );
  // }
}
